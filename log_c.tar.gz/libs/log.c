#include "log.h"
#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#include <sys/syscall.h>
#define gettid() syscall(__NR_gettid)

#define LOG_LINE_BUF_SIZE 1024
#define LOG_ROLL_SIZE 500000000 // 500*1000*1000 500M
#define LOG_FLUSH_INTERVAL 10 // 30s
static const char* log_level2str[] = {
    "debug",
    "info",
    "notice",
    "warn",
    "error",
    "fatal",
    "unknown"
};

log_t* g_log = NULL;

log_t* log_init(const char* fname, log_type type, log_level level, int is_lock) {
    if (type == LOG_NULL) { 
        return NULL;
    }
    
    FILE* file = NULL;
    if (type == LOG_STDOUT) {
        file = stdout;  
    } else {
        file = fopen(fname, "a+");
        if (file == NULL) {
            return NULL;
        }
    }
    log_t* log = malloc(sizeof(log_t));
    log->file  = file;
    log->bytes = 0;
    log->level = level; 
    log->mutex = NULL;
    log->type  = type;
    log->last_flush = 0;
    //strncpy(g_log->fname, fname, sizeof(fname));
    
    if (is_lock) {
        log->mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(log->mutex, NULL);
        printf("pthread_mutex_init\n");
    }
    setbuffer(file, log->buffer, sizeof (log->buffer));

    return log;
}

void _log_flush(log_t* log) {
    fflush(log->file);
}

void log_close(log_t* log) {
    if (log == NULL) return;
    _log_flush(log);
    if (log->mutex) {
        pthread_mutex_destroy(log->mutex);
        free (log->mutex);
        printf("pthread_mutex_destroy\n");
    }
    if (log->type == LOG_FILE) {
        fclose(log->file);
    }
    free(log);

    log = NULL;
}

size_t _log_write(log_t* log, const char* msg, size_t len) {
    return fwrite_unlocked(msg, 1, len, log->file); 
}


void _log_append_unlocked(log_t* log, const char* msg, size_t len) {
    int n = _log_write(log, msg, len);
    assert(n == len);
    log->bytes += n;  

    // TODO roll file
    time_t now = time(NULL);
    if (now  - log->last_flush > LOG_FLUSH_INTERVAL) {
        log->last_flush = now;
        _log_flush(log);
    }
}

void log_append(log_t* log, const char* msg, size_t len) {

    if (log->mutex) {
        pthread_mutex_lock(log->mutex);
        _log_append_unlocked(log, msg, len);
        pthread_mutex_unlock(log->mutex);
    } else {
        _log_append_unlocked(log, msg, len);
    }
}

void log_set_default(log_t* log) {
    g_log = log;
}

void log_write(const char* fname, const char* func, const int line,
        log_level level, const char* format, ...) {
    if (g_log == NULL) {
        return;
    }
    if (level < g_log->level) return;
        
    char buf[LOG_LINE_BUF_SIZE];
    bzero(buf, LOG_LINE_BUF_SIZE);
    char msg[LOG_LINE_BUF_SIZE];
    bzero(msg, LOG_LINE_BUF_SIZE); 

    va_list argv;
    va_start(argv, format);
    vsnprintf(buf, LOG_LINE_BUF_SIZE, format, argv);
    va_end(argv);
    
    char timebuf[32];
    struct tm tm;
    time_t now = time(NULL);
    localtime_r(&now, &tm);
    strftime(timebuf, sizeof timebuf, "%Y-%m-%d %H:%M:%S", &tm);

    size_t len = sprintf(msg, "%s %s %s [%lu:%s:%s:%d]\n", timebuf, log_level2str[level],
            buf, gettid(), fname, func, line);

    log_append(g_log, msg, len);
}
