#include <stdio.h>
#include "log.h"

int main() {

    log_t* log = log_init("test.log", LOG_FILE, LOG_NOTICE, 1);
    if (log == NULL ) {
        printf("log init error.\n");
        return 0;
    }
    log_set_default(log);
    DEBUG("%d, %s", 123, "name");
    INFO("%d, %s", 123, "name");
    NOTICE("%d, %s", 123, "name");
    WARN("%d, %s", 123, "name");
    ERROR("%d, %s", 123, "name");
    FATAL("%d, %s", 123, "name");
    UNKNOWN("%d, %s", 123, "name");

    int i = 1;
    for(; i < 20; ++i) {
        WARN("%d, %s", i, "name");
        sleep(1);
        printf("%d ", i);
        fflush(stdout);
    }

    log_close(log); 
    return 0;
}
