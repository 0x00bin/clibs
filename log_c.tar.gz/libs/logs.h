#include "log.h"
#include "uthash/uthash.h"
struct logs_t {
    char name[16]; // key
    log_t* log;
    void (*write)(log_t* log, const char* msg, size_t len);
    UT_hash_handle hh;
};

struct logs_t* g_logs = NULL;
void add_log(const char* name, log_type type, log_level level) 
{
    log_t* log = log_init(name, type, level, 0);
    if (log == NULL) {
        return;
    }

    struct logs_t *logs ;    
    logs = malloc(sizeof(struct logs_t));
    strcpy(logs->name, name);
    logs->write = log_append;
    HASH_ADD_STR(g_logs, name, logs);
}

struct logs_t* find_log(const char* name)
{
    struct logs_t* logs;
    HASH_FIND_STR(g_logs, name, logs);
    return logs;
}

void del_log(struct logs_t* logs)
{
    HASH_DEL(g_logs, logs);
    free(logs);
}
