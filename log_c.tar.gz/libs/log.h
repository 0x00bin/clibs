#ifndef _LOG_H_
#define _LOG_H_

#include <stdio.h>
#include <pthread.h>
#include <stdarg.h>
#include <stddef.h>

typedef enum {
    LOG_DEBUG,    
    LOG_INFO,
    LOG_NOTICE,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL,
    LOG_UNKNOWN
} log_level;

typedef enum {
    LOG_NULL, //close log output            
    LOG_STDOUT,
    LOG_FILE
} log_type;

typedef struct log_st{
    FILE* file;
    char buffer[64*1024];
    size_t bytes; // written bytes
    log_level level;
    log_type  type;
    pthread_mutex_t* mutex;
    time_t last_flush;
} log_t;

log_t* log_init(const char* fname, log_type type, log_level level, int is_lock);
void log_close(log_t* log);
void log_append(log_t* log, const char* msg, size_t len);

// before calling log_write() must call log_set_default()
void log_set_default(log_t* log);
void log_write(const char* fname, const char* func, const int line,log_level level, const char* format, ...);


#define write_log(level, fmt, ...) log_write(__FILE__, __func__, __LINE__, level, fmt, ##__VA_ARGS__)

// use this must log_set_default();
#define DEBUG(FORMAT, ...)  log_write(__FILE__, __func__, __LINE__, LOG_DEBUG,  FORMAT, ##__VA_ARGS__)
#define INFO(FORMAT, ...)  log_write(__FILE__, __func__, __LINE__, LOG_INFO,  FORMAT, ##__VA_ARGS__)
#define NOTICE(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_NOTICE, FORMAT, ##__VA_ARGS__)
#define WARN(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_WARN, FORMAT, ##__VA_ARGS__)
#define ERROR(FORMAT, ...)   log_write(__FILE__, __func__, __LINE__, LOG_ERROR, FORMAT, ##__VA_ARGS__)
#define FATAL(FORMAT, ...)   log_write(__FILE__, __func__, __LINE__, LOG_FATAL, FORMAT, ##__VA_ARGS__)
#define UNKNOWN(FORMAT, ...)  log_write(__FILE__, __func__, __LINE__, LOG_UNKNOWN,  FORMAT, ##__VA_ARGS__)

#endif
