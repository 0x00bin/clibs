#pragma once

typedef enum {
	MOD_COMMAND_START = 1,
	MOD_COMMAND_STOP
} mod_command_t;


/**
 * @brief 每个模块ipc 模块结构体
 */
struct modipc_t{
	int id;			/*模块id*/

	char *mod_name;		/*模块名字*/

	int socketpair_main;	/*主进程使用的fd*/
	int socketpair_mod;	/*模块进程使用fd*/

	int (*handle_protocol) (struct modipc_t *this, mod_command_t mod_command);
};

/**
 * @brief 创建一个modipc_t结构
 * @return NULL 错误, 反之返回一个结构体地址
 */
struct modipc_t *alloc_a_modipc();

/**
 * @brief 根据协议回调处理函数
 * @return 返回0成功 -1失败
 */
int handle_protocol (struct modipc_t *this, mod_command_t mod_command);

typedef int (*protocol_callback) ();
