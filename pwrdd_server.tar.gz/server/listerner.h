#pragma once

#include "pwrdd_events.h"

/**
 * @brief 创建一个listerner的pwrdd_events结构体
 */
extern struct pwrdd_events *new_listerner_events();

/**
 * @brief listerner的读处理方法
 *
 * @param listerner_events listerner_events的结构体
 *
 * @return 成功返回一个pwrdd_events->type=PWRDD_CONNECTOR的结构体
 */
extern struct pwrdd_events *listerner_read(struct pwrdd_events *listerner_events);
