#include "log_list.h"

log_node_t* log_list_add(log_list_t* this, const char* name, log_type type, log_level level) 
{
    log_t* log = log_create(name, type, level, 0);
    if (log == NULL) {
        return NULL;
    }

    log_node_t* node = malloc(sizeof(log_node_t));
    node->log = log;
    strcpy(node->name, name);
    node->write = log->write;
    HASH_ADD_STR(this->head, name, node);
    return node;
}

log_node_t* log_list_find(log_list_t* this, const char* name)
{
    log_node_t* node;
    HASH_FIND_STR(this->head, name, node);
    return node;
}

void log_list_del(log_list_t* this, log_node_t* node)
{
    HASH_DEL(this->head, node);
    node->log->close(node->log);
    free(node);
}

log_list_t* log_list_create()
{
    log_list_t* list = malloc(sizeof(log_list_t));
    list->head = NULL;
    list->add  = log_list_add;
    list->del  = log_list_del;
    list->find = log_list_find;

    return list;
}
