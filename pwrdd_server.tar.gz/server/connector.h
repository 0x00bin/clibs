#pragma once

#include <kernel_list.h>
#include <time.h>
#include <stdbool.h>
#include <sys/time.h>


/* 10s timeout */
#define SOCKET_TIMEOUT 10000

/* 定义读取的缓冲大小 */
#define READBUFLEN 2048

/**
 * @brief 需要发送的数据结构体
 */
typedef struct send_buf{
	struct list_head list;	/*链表结构*/
	int length;
	int complete;
	char buf[];
}send_buf_t;

/**
 * @brief 每个连接的分配的数据结构
 */
#define SOCKET_TIMEOUT_SECONDS 10
typedef struct connector{
	char *mod_name;				/*握手之后的模块名字*/

	struct circle_buffer *read_buf;		/*读缓冲区*/

	struct timeval timestamp;		/*最后一次读取数据的时间 用于超时处理*/

	struct list_head *write_buf_list;	/*写数据list 当list数据中没有数据代表sock可写,反之代表sock阻塞*/

	void (*set_timeval) (struct connector *this);

}connector_t;


/**
 * @brief 根据给定的ip port sock 返回一个pwrdd_events结构
 * 这个结构将注册到reactor中
 *
 * @param ip	连接过来的ip
 * @param port	连接分配的本地端口
 * @param sock	分配的文件描述符
 *
 * @return NULL错误
 */
struct pwrdd_events *new_connector_events(const char*ip, const int port, const int sock);

#if 0
typedef enum conn_read_types {
	CONN_ERROR = 1,		/* 错误 */
	CONN_NORMAL,		/* 正常读取数据 */
	CONN_EINTR,
	CONN_EAGAIN,
	CONN_CLOSED_BY_PEER,
	CONN_NOT_ENOUGH_ROOM,
} conn_read_types_t;
#endif

/**
 * @brief 连接的读处理方法
 *
 * @param connector_events的结构体
 *
 * @return 
 * 正常返回读到的数据
 * 读到EINTR|EAGAIN返回0
 * -1 错误
 */
int connector_read(struct pwrdd_events *this);
