#include <string.h>
#include "json_helper.h"

json_value* json_find(json_value* data, const char* key)
{
    if (data->type != json_object) {
        return NULL;
    }
    for(int i = 0; i < data->u.object.length; ++i) {
        if (strcmp(data->u.object.values[i].name, key) == 0) {
            return data->u.object.values[i].value;
        }
    }

    return NULL;
}

int json_get_int(json_value* data) {    
    if (data == NULL) {
        return 0;
    }

    if (data->type != json_integer) {
        return 0;
    }

    return data->u.integer;
}

void json_get_string(json_value* data, char* dest) 
{    
    if (data == NULL) {
        return;
    }

    if (data->type != json_string) {
        return;
    }
    memset(dest, 0, data->u.string.length + 1);
    memcpy(dest, data->u.string.ptr, data->u.string.length);
}

int json_get_int_from_object(json_value* data, const char* key) {
    json_value* value = json_find(data, key);
    return json_get_int(value);
}

void json_get_string_from_object(json_value* data, const char* key, char* dest) {    
    json_value* value = json_find(data, key);
    json_get_string(value, dest);
}

json_value* json_get_object_from_object(json_value* data, const char* key) {
    json_value* value = json_find(data, key);
    
    if (value == NULL) {
        return NULL;
    }

    return value;
}

json_value* json_get_object_from_array(json_value* data, int i) {
    if (data == NULL || data->type != json_array) {
        return NULL;
    }

    if (i < data->u.array.length) {
        return data->u.array.values[i];
    }
    return NULL;
}


int get_int_from_array(json_value* data, const char* key, int i) {
    json_value* value = json_get_object_from_array(data, i);
    value = json_find(value, key);
    return json_get_int(value);
}

void get_string_from_array(json_value* data, const char* key, int i, char* dest) 
{
    json_value* value = json_get_object_from_array(data, i);
    value = json_find(value, key);
    json_get_string(value, dest);    
}


