#pragma once
#include "json.h"

int  json_get_int_from_object(json_value* data, const char* key);
void json_get_string_from_object(json_value* data, const char* key, char* dest);

int  json_get_int_from_array(json_value* data, const char* key, int i);
void json_get_string_from_array(json_value* data, const char* key, int i, char* dest);

json_value* json_get_object_from_object(json_value* data, const char* key);
json_value* json_get_object_from_array(json_value* data, int idx);
