#include <stdio.h>
#include <math.h>
#include <string.h>
#include "json.h"
#include "json_helper.h"

int main() {
    char data[] = "{\"myint\":1,\"mystr\":\"mystr values\",\
         \"myarr\":[{\"aint\":1,\"astr\":\"astr value\"},\
                  {\"aint\":2,\"astr\":\"astr value2\"}],\
         \"myobj\":{\"oint\":123,\"ostr\":\"objstr value\"}}";

    char error[256];
    json_settings settings = {0};    
    json_value * root = json_parse_ex(&settings, data, strlen(data), error);
    if (root == 0) {
        printf("json parse error:%s\n", error);
        return 0;
    }

    int myint = json_get_int_from_object(root, "myint");
    printf("myint:%d\n", myint);
    
    char mystr[16];
    json_get_string_from_object(root, "mystr", mystr);
    printf("mystr:%s\n", mystr);

    json_value* myarray = json_get_object_from_object(root,"myarr");
    int i = 0;    
    json_value* object = NULL;
    while(object = json_get_object_from_array(myarray, i++)) {
        myint = json_get_int_from_object(object, "aint");
        json_get_string_from_object(object, "astr", mystr);
        printf("aint:%d,astr:%s\n", myint, mystr);
    } 
    
    
    json_value* myobj = json_get_object_from_object(root,"myobj");
    
    myint = json_get_int_from_object(myobj, "oint");
    printf("oint:%d\n", myint);
    
    json_get_string_from_object(myobj, "ostr", mystr);
    printf("ostr:%s\n", mystr);

    json_value_free(root);
    return 0;
}
