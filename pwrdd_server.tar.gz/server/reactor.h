#pragma once

#include "pwrdd_events.h"
#include <kernel_list.h>



typedef enum command_types {
	CMD_ERROR = 1,
	CMD_NOT_COMPLETE,
}command_types_t;

struct reactor{

	int epfd;
	int maxevents;
	int ep_timeout;	/* epoll的超时时间 usec */

	struct list_head connector_list;	

	int  (*init)	(struct reactor *this);
	int  (*checkin)	(struct reactor *this, struct pwrdd_events *a_pwrdd_events);
	int  (*run)	(struct reactor *this);
	void (*clean)	(struct reactor *this);

	void (*read)	(struct reactor *this, void *ptr);
	void (*write)	(struct reactor *this, void *ptr);
	void (*timeout)	(struct reactor *this);
	void (*remove)	(struct pwrdd_events *a_pwrdd_events);
	void (*command)	(struct reactor *this, void *ptr);
};

struct reactor *new_reactor();
