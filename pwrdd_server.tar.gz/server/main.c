#include <pwrd_socket.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>

#include <pwrd_socket.h>
#include "configure.h"
#include "reactor.h"
#include "log_service.h"
#include "libs/log.h"
#include "libs/log_defs.h"

void *log_service_thread(void *args)
{
	struct configure_log *conf = get_configure_log();
	log_service_run(conf->log_dir, conf->default_level, conf->default_output);

	return NULL;
}

int set_default_output()
{
	struct configure_log *conf = get_configure_log();

	int type = log_str2type(conf->default_output); 
	if ( -1 == type) {
		printf("%s unknow log type.\n", conf->default_output);
		return -1;
	}
    
    int level = log_str2level(conf->default_level);
    if (level == -1) {        		
		printf("unknow log level.\n");
        return -1;
    }

	log_t *log = log_create("main.log", (log_type)type, (log_level)level, true);

	log->set_default(log);

	return 0;
}

int main (int argc, char* args[]) 
{

	/* handle configure */
	if (access(args[1], R_OK)) {
		printf("usage: %s configure \n", args[0]);
		return -1;
	}
	configure_init("configure.ini");
	display_configure();

	/* log service */
	pthread_t tid;
	if (0 != pthread_create(&tid, NULL, log_service_thread, NULL)) {
		printf("create log_thread error.\n");
		return -1;
	}

	/* set default output */
	if (set_default_output() < 0)
		return -1;

	DEBUG("%s", "This is a test message.");
	/* reactor */
	struct reactor *a_reactor = new_reactor();
	a_reactor->init(a_reactor);

	for (;;)
		a_reactor->run(a_reactor);

	a_reactor->clean(a_reactor);

	return 0;
}
