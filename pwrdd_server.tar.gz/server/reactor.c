#include "reactor.h"
#include "configure.h"
#include "pwrdd_events.h"
#include "connector.h"
#include "libs/log.h"
#include "libs/circle_buffer.h"
#include "listerner.h"
#include <kernel_list.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <errno.h>
#include <time.h>
#include <pwrd_socket.h>
#include <assert.h>

/*
int  reactor_init	(struct reactor *this);
int  reactor_checkin	(struct reactor *this, struct pwrdd_events *pwrdd_event);
int  reactor_run	(struct reactor *this);
void reactor_clean	(struct reactor *this);

void reactor_read	(struct reactor *this, void *ptr);
void reactor_write	(struct reactor *this, void *ptr);
void reactor_timeout	(struct reactor *this);
void reactor_remove	(struct reactor *this);
*/


int reactor_checkin(struct reactor *this, struct pwrdd_events *a_pwrdd_events)
{
	struct epoll_event event;

	switch (a_pwrdd_events->type) {
	case PWRDD_LISTERNER: 
		event.events = EPOLLIN;
		break;
	case PWRDD_CONNECTOR:
		event.events = EPOLLIN|EPOLLOUT|EPOLLET;
		list_add(&a_pwrdd_events->list, &this->connector_list);
		break;
	case PWRDD_SIGNAL:
		event.events = EPOLLIN;
		break;
	default:
		assert(0 == 1);
	}

	event.data.ptr = a_pwrdd_events;

	if (epoll_ctl(this->epfd, EPOLL_CTL_ADD, a_pwrdd_events->sock, &event) < 0) {
		PWRDD_EVENT_PRT(ERROR, strerror(errno), a_pwrdd_events);
		return -1;
	}

	PWRDD_EVENT_PRT(NOTICE, "checkin", a_pwrdd_events);

	return 0;
}

int reactor_init(struct reactor *this)
{
	this->maxevents = 5;
	this->ep_timeout = -1;

	if ((this->epfd=epoll_create(this->maxevents)) < 0)
		return -1;

	INIT_LIST_HEAD(&this->connector_list);

	struct pwrdd_events *listerner_events = new_listerner_events();

	this->checkin(this, listerner_events);

	return 0;
}

int reactor_run(struct reactor *this)
{
	struct epoll_event events[this->maxevents];
	int n = epoll_wait(this->epfd, events, this->maxevents, this->ep_timeout);

	if (n < 0) {
		if (errno == EINTR)
			return 0;

		return -1;
	}

	for (int i=0; i < n; ++i) {
		struct epoll_event *ev = &events[i];

		if (ev->events | EPOLLIN)
			this->read(this, ev->data.ptr);

		if (ev->events | EPOLLOUT)
			this->write(this, ev->data.ptr);
	}


	this->timeout(this);

	return 0;
}

void reactor_clean(struct reactor *this)
{
}

void reactor_command (struct reactor *this, void *ptr)
{
	struct pwrdd_events *a_pwrdd_events = ptr;
	struct connector *conn = a_pwrdd_events->ptr;

	if (a_pwrdd_events->type == PWRDD_CONNECTOR) {
		
		struct circle_buffer *read_buf = conn->read_buf;


		int cr_lf = read_buf->find(conn->read_buf, "\r\n");

	printf ("-----cr_lf=%d---------free=%d, used=%d\n", cr_lf, read_buf->free(read_buf), read_buf->used(read_buf));
		if (cr_lf < 0)
			return;

		char cmd[cr_lf + 2];
		read_buf->get(read_buf, cmd, cr_lf + 2);
		assert(cmd[cr_lf]   == '\r');
		assert(cmd[cr_lf+1] == '\n');
		cmd[cr_lf] = 0;

		PWRDD_EVENT_PRT(NOTICE, cmd, a_pwrdd_events);

		//handle_command(cmd);
	}
}

void reactor_read (struct reactor *this, void *ptr)
{
	struct pwrdd_events *a_pwrdd_events = ptr;

	if (a_pwrdd_events->type == PWRDD_LISTERNER) {

		struct pwrdd_events *new_pwrdd_events = listerner_read(a_pwrdd_events);
		this->checkin(this, new_pwrdd_events);

	} else if (a_pwrdd_events->type == PWRDD_CONNECTOR) {
		int n = connector_read(a_pwrdd_events);

		if (n < 0) {
			list_del(&a_pwrdd_events->list);
			this->remove(a_pwrdd_events);
		} else if (n > 0) {
			this->command(this, ptr);
		}


	} else if (a_pwrdd_events->type == PWRDD_SIGNAL) {
	}
}

void reactor_write (struct reactor *this, void *ptr)
{
}

void reactor_timeout (struct reactor *this)
{
	struct timeval tv;
	gettimeofday(&tv, NULL);

	struct list_head *del_ptr, *ptr;
	for (ptr=this->connector_list.prev; ptr != &this->connector_list;) {

		struct pwrdd_events *a_pwrdd_events = (struct pwrdd_events *)list_entry(ptr, struct pwrdd_events, list);
		struct connector *a_connector = a_pwrdd_events->ptr;

		int usec = (tv.tv_sec - a_connector->timestamp.tv_sec)*1000000 + tv.tv_usec - a_connector->timestamp.tv_usec;
		int msec = SOCKET_TIMEOUT - usec/1000;

		if (msec <=0) {
			del_ptr = ptr;
			ptr = ptr->prev;
			list_del(del_ptr);

			PWRDD_EVENT_PRT(NOTICE, "timeout", a_pwrdd_events);

			this->remove(a_pwrdd_events);
		} else {
			if (this->ep_timeout < 0 || this->ep_timeout > msec)
				this->ep_timeout = msec;

			ptr = ptr->prev;
		}
	}

	if (this->connector_list.prev == &this->connector_list)
		this->ep_timeout = -1;
}

void reactor_remove (struct pwrdd_events *a_pwrdd_events)
{

	PWRDD_EVENT_PRT(DEBUG, "remove", a_pwrdd_events);

	if (a_pwrdd_events->sock > 0)
		close(a_pwrdd_events->sock);

	a_pwrdd_events->clean(a_pwrdd_events);
}

struct reactor *new_reactor()
{
	struct reactor *a_reactor = malloc(sizeof(struct reactor));

	a_reactor->init	   = reactor_init;
	a_reactor->checkin = reactor_checkin;
	a_reactor->run     = reactor_run;
	a_reactor->clean   = reactor_clean;

	a_reactor->read    = reactor_read;
	a_reactor->write   = reactor_write;
	a_reactor->timeout = reactor_timeout;
	a_reactor->remove  = reactor_remove;
	a_reactor->command  = reactor_command;

	return a_reactor;
}
