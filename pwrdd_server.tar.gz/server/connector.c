#include "connector.h"
#include "configure.h"
#include "pwrdd_events.h"
#include <pwrd_socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include "libs/log.h"
#include <errno.h>
#include "libs/circle_buffer.h"
#include <stdbool.h>

void connector_set_timeval (struct connector *this) {
	gettimeofday(&this->timestamp, NULL);
}

int connector_write(struct pwrdd_events *this)
{
	return 0;
}

#if 0
conn_read_types_t connector_handle_command(struct pwrdd_events *this)
{

	struct circle_buffer *read_buf = this->ptr->read_buf;
	
	int cr_lf = read_buf->find(conn->read_buf, "\r\n");

	if (cr_lf < 0)
		return CONN_NORMAL;

	char cmd[cr_lf + 2];
	read_buf->get(read_buf, cmd, cr_lf + 2);
	assert(cmd[cr_lf]   == '\r');
	assert(cmd[cr_lf+1] == '\n');
	cmd[cr_lf] = 0;

	PWRDD_EVENT_PRT(NOTICE, cmd, a_pwrdd_events);

}
#endif

int connector_read(struct pwrdd_events *this)
{

	struct connector *conn = this->ptr;

	char buf[READBUFLEN];

	struct circle_buffer *read_buf = conn->read_buf;

	int size=0;
	do {
		int n = read(this->sock, buf, READBUFLEN);

		if (n < 0) {
			if (errno == EINTR) {
				PWRDD_EVENT_PRT(DEBUG, "EINTR", this);
				return 0;
			}

			if (errno == EAGAIN) {
				PWRDD_EVENT_PRT(DEBUG, "EAGAIN", this);
				return 0;
			}

			PWRDD_EVENT_PRT(ERROR, strerror(errno), this);
			return -1;
		} else if (n == 0) {
			PWRDD_EVENT_PRT(ERROR, "closed by peer.", this);
			return -1;
		}

		size += n;

		DEBUG("ip=%s:port=%d:sock=%d:type=%s:ptr=%p:readn=%d:data=%.*s",
				this->ip,
				this->port,
				this->sock,
				pwrdd_events_types_2_string(this->type),
				this->ptr,
				n,
				n,
				buf);

		for (int i=0; i<n; ++i)
			printf("%d ", buf[i]);

		printf("\n");

		if (read_buf->addn(read_buf, buf, n) < 0) {
			PWRDD_EVENT_PRT(ERROR, "It's not enough room in circle buffer.", this);
			return -1;
		}

		if (n < READBUFLEN)
			break;
	} while (true);

	conn->set_timeval(conn);

	return size;
}

int connector_init(struct pwrdd_events *this)
{
	struct connector *conn= malloc(sizeof(struct connector));
	bzero(conn, sizeof(struct connector));

	//gettimeofday(&conn->timestamp, NULL);
	conn->mod_name       = NULL;
	conn->read_buf       = new_circle_buffer(READBUFLEN);
	conn->write_buf_list = NULL;
	conn->set_timeval    = connector_set_timeval;

	conn->set_timeval(conn);

	this->ptr  = conn;

	return 0;
}

void connector_clean(struct pwrdd_events *this)
{
	if (!this->ptr)
		free(this);

	struct connector *conn = this->ptr;

	conn->read_buf->clean(conn->read_buf);

	free(conn->mod_name);

	/* 还要释放write buf list */
}

struct pwrdd_events *new_connector_events(const char*ip, const int port, const int sock)
{
	struct pwrdd_events *a_pwrdd_events = malloc(sizeof(struct pwrdd_events));

	strncpy(a_pwrdd_events->ip, ip, 16);
	a_pwrdd_events->type  = PWRDD_CONNECTOR;
	a_pwrdd_events->port  = port;
	a_pwrdd_events->sock  = sock;
	a_pwrdd_events->init  = connector_init;
	a_pwrdd_events->clean = connector_clean;

	a_pwrdd_events->init(a_pwrdd_events);

	NOTICE("accept new_ip=%s:new_port=%d:new_sock=%d", 
			a_pwrdd_events->ip,
			a_pwrdd_events->port,
			a_pwrdd_events->sock);

	return a_pwrdd_events;
}
