#include "pwrdd_events.h"
#include "connector.h"
#include "configure.h"
#include "libs/pwrd_socket.h"
#include "libs/log.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

int listerner_init(struct pwrdd_events *this)
{
	struct configure_server *configure_server = get_configure_server();

	strncpy(this->ip, configure_server->ip, 16);
	this->port = configure_server->port;
	this->sock = pwrd_listerner(configure_server->ip, configure_server->port, true);

	if (this->sock < 0) {
		FATAL("listerner ip=%s:port=%d:err=%m", configure_server->ip, configure_server->port);
		exit(-1);
	}

	this->type = PWRDD_LISTERNER;
	this->ptr  = NULL;

	NOTICE("listerner_ip=%s:listerner_port=%d:listerner_sock=%d:msg=SUCCESSED", 
			configure_server->ip, 
			configure_server->port,
			this->sock);

	return 0;
}

void listerner_clean(struct pwrdd_events *this)
{
	close(this->sock);
	free(this);
}

struct pwrdd_events *new_listerner_events()
{

	struct pwrdd_events *listerner_events = malloc(sizeof(struct pwrdd_events));

	listerner_events->init  = listerner_init;
	listerner_events->clean = listerner_clean;


	listerner_events->init(listerner_events);

	return listerner_events;
}


struct pwrdd_events *listerner_read(struct pwrdd_events *listerner_events)
{
	char ip[16];
	int port;

	int sock = pwrd_accept(listerner_events->sock, ip, &port);

	if (sock < 0) {
		PWRDD_EVENT_PRT(ERROR, strerror(errno), listerner_events);
		return NULL;
	}

	pwrd_set_noblock(sock);

	return new_connector_events(ip, port, sock);
}
