#include <stdio.h>

#include "libs/log.h"

void print_log(const char* name) {
    INFO("-----------I'am line.----------------");
    DEBUG("testmsg1 mod:%s %d", name, 12345);
    INFO("testmsg2 mod:%s %s", name,"I'm string.");
    NOTICE("testmsg3 mod:%s %d", name, 123456);
    WARN("testmsg4 mod:%s %d", name, 12345);
    ERROR("testmsg5 mod:%s %d", name, 12345);
    FATAL("testmsg6 mod:%s %d", name, 12345);
    UNKNOWN("testmsg7 mod:%s %d", name, 12345);
}
int main() {

    log_t* log = log_create("test", LOG_UDP, LOG_DEBUG, false);
    if (log == NULL) {
        printf("log create error.");
        return 1;
    }
    log->set_default(log);
    //DEBUG("mod:%s123 %d", 12345);
    print_log("test");
    log_t* monitor = log_create("monitor", LOG_STDOUT, LOG_NOTICE, false);
    monitor->set_default(monitor);
    print_log("monitor");
    
    log->set_default(log);
    print_log("test");
    monitor->close(monitor);
    log->close(log);
    return 0;
}
