#!/bin/sh
gcc -g -Wall -std=gnu99 -o log_server test_log_service.c log_service.c log_list.c libs/log.c libs/pwrd_socket.c -lpthread -D_LOG_LOCAL -D_LOG_NOBUFF

gcc -g -Wall -std=gnu99 -o log_client test_log_udp.c libs/log.c libs/pwrd_socket.c -D_LOG_UDP
