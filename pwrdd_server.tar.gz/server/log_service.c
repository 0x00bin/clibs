#include <sys/socket.h>
#include <assert.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "log_list.h"
#include "log_service.h"
#include "libs/log_msg.h"
#include "libs/pwrd_socket.h"

#define LOG_PATH_SIZE 32
typedef struct log_service_t {
    char        path[LOG_PATH_SIZE]; // log file path
    log_level   level;       // log default level;
    log_type    type;        // log default type;
    log_list_t* list;        // log list
} log_service_t;

void log_service_on_message(log_msg_t* msg, log_service_t* service) 
{
    DEBUG("name:%s, data:%s", msg->name, msg->data);    
    
    char name[LOG_PATH_SIZE]; // define log prefix path
    snprintf(name, LOG_PATH_SIZE, "%s/%s.log", service->path, msg->name);
    DEBUG("log path:%s", name);
   
    log_list_t* list = service->list;
    log_node_t* log_node = list->find(list, name);
    if (log_node == NULL) {
        log_node = list->add(list, name, service->type, service->level);
    }
    assert(log_node != NULL);// TODO log_node is NULL return errno

    log_node->write(log_node->log, msg->data, strlen(msg->data));
}

void log_service_run(const char* dir, const char* default_level, const char* default_type) 
{
    char name[LOG_PATH_SIZE]; // define log prefix path
    snprintf(name, LOG_PATH_SIZE, "%s/log.log", dir);
    // mkdir dir
    if ( access(dir, F_OK) != 0 ) {
        if (mkdir(dir, 0755) != 0) {
            printf("mkdir %s err:%s\n", dir, strerror(errno));
            return;
        }
    }

    log_t* log = log_create(name, LOG_STDOUT, LOG_DEBUG, false);
    log->set_default(log);
    int listen_sock = pwrd_unix_listerner(LOG_UDP_SOCK, false);  
    if (listen_sock == -1) {
        ERROR("sock=%s, err=%s", LOG_UDP_SOCK, strerror(errno));
        return;
    }
    
    // load conf
    log_service_t service;
    snprintf(service.path, LOG_PATH_SIZE, "%s", dir);
    INFO("log default level:%s, path:%s",default_level, service.path);
    
    int level = log_str2level(default_level);
    if (level == -1) {
        ERROR("log service default level[%s] is error.", default_level);
        return; 
    }
    int type = log_str2type(default_type);
    if (type == -1) {
        ERROR("log service default type[%s] is error.", default_type);
        return; 
    }
    service.type  = (log_type) type;
    service.level = (log_level)level;
    service.list  = log_list_create(); 
    
    log_msg_t msg;
    struct sockaddr_un addr;
    socklen_t len = sizeof(addr); 
    
    INFO("log service start: %d", listen_sock);
    while(1) {
        int size = recvfrom(listen_sock, &msg, sizeof(msg), 0, (struct sockaddr *)&addr, &len);
        if (size == -1) {
            WARN("recvfrom error.");
            continue;
        }
        log_service_on_message(&msg, &service);
    } // while

    // Never reach
    log->close(log);
}
