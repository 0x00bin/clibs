#pragma once

#include <stdbool.h>

struct reactor_t;
struct address_t;
struct connection_t;
struct circle_buffer;

typedef struct client_t {
    _Bool (*connect)     (struct client_t* this, struct address_t* address);
    void  (*close)       (struct client_t* this);
    void  (*onmessage)   (struct connection_t* connection, struct circle_buffer* buffer, void* ptr); 
    void  (*new_connection) (struct client_t* this, struct connection_t* connection);
    void  (*onconnection) (struct connection_t* connection);

    struct connector_t*  connector;
    struct reactor_t*    reactor;
    struct connection_t* connection;
} client_t;

client_t* new_client(struct reactor_t* reactor);
