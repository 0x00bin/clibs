#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <string.h>

#include "address.h"

_Bool address_init(address_t* this, uint16_t port, const char* ip) {
     bzero(&(this->addr), sizeof(this->addr));
//    bzero(this, sizeof(this));

    this->addr.sin_family = AF_INET;
    this->addr.sin_port = htons(port);

    sprintf(this->port, "%d", port);
    if (ip == NULL) {
        this->addr.sin_family = AF_INET;
        this->addr.sin_addr.s_addr = htonl(INADDR_ANY);
    } else {
        memcpy(this->ip, ip, strlen(ip));
        if (inet_pton(AF_INET, ip, &(this->addr.sin_addr)) <= 0) {
            return false;
        }
    }
    return true;
}


