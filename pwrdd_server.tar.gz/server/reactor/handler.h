#pragma once

typedef enum {
    ReadEvent  = 0x01,
    WriteEvent = 0x02,
    ErrorEvent = 0x04,
    EventMask  = 0xff
} event_t;

#define HANDLER(type)   \
    int handle; \
    void (*onread)  (struct handler_t* this); \
    void (*onwrite) (struct handler_t* this); \
    void (*onerror) (struct handler_t* this); \
    struct reactor_t* reactor;

struct reactor_t;
typedef struct handler_t {
    HANDLER(handler_t);
} handler_t;
