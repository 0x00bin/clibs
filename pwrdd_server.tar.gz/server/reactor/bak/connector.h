#pragma once

#include "handler.h"

struct client_t;
struct reactor_t;
struct address_t;
struct connection_t;
typedef struct connector_t {
    HANDLER(connector_t);
    void (*connect) (struct connector_t* this, struct address_t* address);
    struct client_t client;
} connector_t;

connector_t* new_connector(struct reactor_t* reactor, struct client_t* client);
