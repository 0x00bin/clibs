#pragma once
#include "handler.h"

struct hash_table_t;

typedef struct epoller_t {
    int epfd;
    int fd_nums;

    int (*wait_events)    (struct epoller_t* this, struct hash_table_t* handlers, int timeout);
    int (*register_event) (struct epoller_t* this, int fd, event_t e);
    int (*remove_event)   (struct epoller_t* this, int fd);

} epoller_t;

epoller_t* epoller_create();
