#pragma once

#include "handler.h"

struct server_t;
struct reactor_t;
struct connection_t;

typedef struct acceptor_t {
    HANDLER(acceptor_t)
 //   void (*new_connection) (struct server_t* this, struct connection_t* connection);
    struct server_t*  server;
} acceptor_t;

acceptor_t* acceptor_create(struct server_t* server, int sock, struct reactor_t* reactor);
