#pragma once 

#include <stdbool.h>
#include <netinet/in.h>

#define IP_SIZE 16
#define PORT_SIZE 8

typedef struct address_t {
    void (*init) (struct address_t* this, uint16_t port, char* ip);    
    
    struct sockaddr_in addr;

    char ip[IP_SIZE];
    char port[PORT_SIZE];
} address_t;

_Bool address_init(address_t* this, uint16_t port, const char* ip);
