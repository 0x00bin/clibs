#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <strings.h>

#include "connection.h"
#include "reactor.h"
#include "circle_buffer.h"

void connection_close(connection_t* this)
{
    printf("close connection\n");
    close(this->handle);
    this->reactor->remove_handler(this->reactor, (handler_t*)this);
    free(this);
}

void connection_onread(handler_t* this)
{
    connection_t* _this = (connection_t*)this;
    int len = _this->read_buffer_->add_from_fd(_this->read_buffer_, this->handle);
    if (len > 0){
        printf("onread len:%d fd:%d\n", len, this->handle);
        _this->reactor->register_handler(_this->reactor, this, WriteEvent);
        // TODO call onMessage function
        if (_this->onmessage) {
      //      char buffer[BUFSIZ];
        //    int n = _this->read_buffer_->get(_this->read_buffer_, buffer, BUFSIZ);

            _this->onmessage(_this, _this->read_buffer_, _this->callback_optr);
        }
    } else {
        // TODO read error
    }
}

int connection_send(connection_t* this, const char* msg, int len)
{
    return this->write_buffer_->addn(this->write_buffer_, msg, len);
}

void connection_onwrite(handler_t* this)
{
    connection_t* _this = (connection_t*)this;
    char buffer[BUFSIZ];
    int n = _this->write_buffer_->get(_this->write_buffer_, buffer, BUFSIZ);
    if (n == 0) {
        printf("no data to send\n");
        return;
    } 
    int len = send(_this->handle, buffer, n, 0);
    if (len > 0) {
        printf("onwrite len:%d\n", len);
        _this->reactor->register_handler(_this->reactor, this, ReadEvent);        
    } else {                        
        if ( len == 0 || len < 0 && errno == ECONNRESET) {
            printf("connection close/reset by client:%d, len:%d, errno:%s\n", this->handle,len, strerror(errno));
            connection_close(_this);
        }
        printf("send\n");
        // TODO error
    }
}

void connection_onerror(handler_t* this)
{
    printf("onerror fd:%d\n", this->handle);
    connection_close((connection_t*)this);   
}

connection_t* connection_create(int handle, struct reactor_t* reactor)
{
    connection_t* connection = malloc(sizeof(connection_t));
    connection->handle  = handle; 
    connection->reactor  = reactor;
    connection->onread   = connection_onread;
    connection->onwrite  = connection_onwrite;
    connection->onerror  = connection_onerror;
    connection->send     = connection_send;
    connection->close    = connection_close;

    connection->onmessage     = NULL; 
    connection->callback_optr = NULL;
    
   // connection->register_handler = reactor->register_handler;
    //connection->remove_handler   = reactor->remove_handler;           
    
    connection->read_buffer_  = new_circle_buffer(BUFSIZ);
    connection->write_buffer_ = new_circle_buffer(BUFSIZ);
    
    bzero(connection->ip,   IP_SIZE);
    bzero(connection->port, PORT_SIZE);

    // set ip port
    struct sockaddr addr;
    int addrlen = sizeof(addr);
    bzero(&addr, addrlen);
    if ( getpeername(handle, &addr,&addrlen) == 0 ) {
        if (getnameinfo(&addr, addrlen, connection->ip, IP_SIZE, 
            connection->port, PORT_SIZE, NI_NUMERICHOST | NI_NUMERICSERV) == 0) {
            printf("(ip:%s, port:%s)\n", connection->ip, connection->port);
        }
    }

    return connection;
}
