#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "connector.h"
#include "connection.h"
#include "address.h"
#include "client.h"
#include "reactor.h"

void connector_new_connection(struct handler_t* this) 
{       
    connection_t* connection = connection_create(this->handle, this->reactor);
    connector_t* _this = (connector_t*) this;
    _this->client->new_connection(_this->client, connection);
}

_Bool connector_connect(connector_t* this, address_t* address) 
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK) == -1) {
        goto error;
    }
    if (fcntl(fd, F_SETFD, fcntl(fd, F_GETFD, 0) | FD_CLOEXEC) == -1) {
        goto error;        
    }
    // EINPROGRESS，连接还在进行中。后面可以通过poll或者select来判断soc如果可以写，说明连接完成了。 
    if (connect(fd, (struct sockaddr*)&(address->addr), sizeof(address->addr)) < 0 ) {
        if (errno != EINPROGRESS) {
            goto error;
        }
    }
    
    this->reactor->register_handler(this->reactor, (handler_t*)(this), WriteEvent);
     
    this->handle = fd;
    return true;

error:
    printf("connect error:%s\n", strerror(errno));
    close(fd);
    return false;
}

connector_t* new_connector(reactor_t* reactor, client_t* client) {
    connector_t* connector = malloc(sizeof(connector_t));
    connector->handle  = 0;
    
    connector->reactor = reactor; 
    connector->client  = client;

    connector->connect = connector_connect;
    connector->onwrite = connector_new_connection;

    //connector->new_connection = client->new_connection;
    return connector;
}
