#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "acceptor.h"
#include "reactor.h"
#include "server.h"
#include "handler.h"
#include "connection.h"

void acceptor_accept(handler_t* this) 
{    
    struct sockaddr addr;
    socklen_t addrlen = sizeof(addr);
    // new connection
    int handle = accept(this->handle, &addr, &addrlen);
    
    if ( handle == -1 ) {
        printf("accept errno:%d\n", errno);
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            //break; 
            return;
        } else {
            printf("accept errno:%d\n", errno);
        } 
    }
    
    printf("accept fd:%d\n", handle); 
    connection_t* connection = connection_create(handle, this->reactor);
    acceptor_t* _this = (acceptor_t*)this;
    // set onmessage callback
    connection->onmessage = _this->server->onmessage;

    _this->server->new_connection(_this->server, connection);
    _this->reactor->register_handler(_this->reactor, (handler_t*)(connection), ReadEvent);
}

acceptor_t* acceptor_create(server_t* server, int handle, struct reactor_t* reactor)
{
    acceptor_t* acceptor = malloc(sizeof(acceptor_t));
    acceptor->handle = handle;
    acceptor->server   = server;
    acceptor->reactor  = reactor;
    acceptor->onread   = acceptor_accept;

//    acceptor->new_connection   = server->new_connection;
//    acceptor->register_handler = reactor->register_handler;

    return acceptor;
}

