#include <stdlib.h>
#include "client.h"
#include "connection.h"
#include "address.h"
#include "reactor.h"
#include "connector.h"

void client_close(client_t* this) 
{
    if (this->connection) {
        this->connection->close(this->connection);
    }
    free(this);
}

void client_new_connection(client_t* this, connection_t* connection) 
{
    this->connection = connection;
    connection->onmessage = this->onmessage;
    this->reactor->register_handler(this->reactor, (handler_t*)(connection), WriteEvent);    
    
    if (this->onconnection) {
        this->onconnection(connection);
    }
}

_Bool client_connect(client_t* this, address_t* address) 
{
    return this->connector->connect(this->connector, address);
}


client_t* new_client(reactor_t* reactor) {
    client_t* client = malloc(sizeof(client_t));
    client->reactor    = reactor;

    client->connector  = new_connector(reactor, client);
    
    client->connect    = client_connect;
    client->close      = client_close;
    
    client->new_connection = client_new_connection;

    client->connection   = NULL;
    client->onmessage    = NULL;
    client->onconnection = NULL;

    return client;
}
