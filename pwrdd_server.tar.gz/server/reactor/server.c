#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "server.h"
#include "connection.h"
#include "acceptor.h"

void server_new_connection(server_t* this, connection_t* connection) 
{
    printf("has new_connection\n");
    if (this->onconnection) {
        this->onconnection(connection);
    }
    //    connection_t* this->acceptor_->accept(this->acceptor_);
   // add connection to clients 
}

_Bool socket_setnonblock(int fd)
{    
    int fl = fcntl(fd, F_GETFL, 0);
    fl |= O_NONBLOCK;
    if ( fcntl(fd, F_SETFL, fl) == -1) {
        printf("fcntl set NONBLOCK error.\n");
        return false;
    }
    return true;
}

_Bool server_start(server_t* this)
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        printf("\nsocket error.\n");
        return false;
    }
    
    int opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
        printf("set SO_REUSEADDR error. %s\n", strerror(errno));
        return false;
    }
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(this->port_);
    addr.sin_addr.s_addr = inet_addr(this->ip_);
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        printf("\nbind error. %s\n", strerror(errno));
        return false;
    }
    
    // set nonblock
    if ( !socket_setnonblock(sock) ) {
        return false;
    }

    if (listen(sock, 10) < 0) {
        printf("listen error.\n");
        return false;
    }    

    this->acceptor = acceptor_create(this, sock, this->reactor);
    printf("server start\n"); 
    return true;
}

server_t* server_create(struct reactor_t* reactor, const char* ip, uint16_t port)
{
    server_t* server = malloc(sizeof(server_t));
    bzero(server->ip_, sizeof(server->ip_));
    memcpy(server->ip_, ip, strlen(ip));
    server->port_    = port;
    server->acceptor = NULL;
    
    server->start          = server_start;
    server->new_connection = server_new_connection;
    server->onmessage      = NULL;
    server->onconnection   = NULL;

    server->reactor  = reactor;
    return server;
}

