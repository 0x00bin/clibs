#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifndef   IP_SIZE
#define   IP_SIZE 16
#endif
struct reactor_t;
struct acceptor_t;
struct connection_t;
struct circle_buffer;
typedef struct server_t {
    char        ip_[IP_SIZE];
    uint16_t    port_;
    struct acceptor_t* acceptor;
    struct reactor_t*  reactor;
    _Bool       (*start)(struct server_t* this);
    
    void (*new_connection) (struct server_t* this, struct connection_t* connection); 
    void (*onmessage)(struct connection_t* connection, struct circle_buffer* buffer, void* ptr);
    void (*onconnection) (struct connection_t* connection);
    //connections     connections_;
} server_t;

server_t* server_create(struct reactor_t* reactor, const char* ip, uint16_t port);
