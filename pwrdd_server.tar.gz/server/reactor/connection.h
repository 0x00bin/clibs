#pragma once

#include "handler.h"

#ifndef   IP_SIZE
#define   IP_SIZE 16
#endif

#ifndef   PORT_SIZE
#define   PORT_SIZE 8
#endif
struct reactor_t;
struct circle_buffer;

typedef struct connection_t {
    HANDLER(connection_t);
    struct circle_buffer* write_buffer_;
    struct circle_buffer* read_buffer_;
    
    int  (*send)           (struct connection_t* this, const char* msg, int len);
    void (*onmessage)      (struct connection_t* this, struct circle_buffer* buffer, void* optr);
    void (*close)          (struct connection_t* this);
    //int  (*remove_handler) (struct reactor_t* this, handler_t* handler);
    
    char  ip[IP_SIZE];
    char  port[PORT_SIZE];
    void* callback_optr; // callback object ptr;
} connection_t;

connection_t* connection_create(int handle, struct reactor_t* reactor);

