#include <stdio.h>
#include <strings.h>
#include <string.h>

#include "reactor.h"
#include "server.h"
#include "connection.h"
#include "circle_buffer.h"
#include "json/json.h"

void onmessage(connection_t* connection, circle_buffer_t* buffer, void* ptr) {
    char buff[BUFSIZ]; 
    int n = buffer->get(buffer, buff, BUFSIZ);
    printf("recv:[%s] len: %d, strlen:%d, fd:%d\n", buff, n, strlen(buff), connection->handle);
    bzero(buff, BUFSIZ);
    sprintf(buff, "hello, %d", connection->handle);
    connection->send(connection, buff, strlen(buff));
}

void onconnection(connection_t* connection) {    
    printf("onconnection ip:%s, port:%s\n", connection->ip, connection->port);
}

int main()
{
    reactor_t*  reactor  = reactor_create(10);
    server_t*   server   = server_create(reactor, "127.0.0.1", 8889);
    server->start(server);
    // set onmessage onconnection callback
    server->onmessage    = onmessage;
    server->onconnection = onconnection;

    while(1) {
        reactor->register_handler(reactor, (handler_t*)server->acceptor, ReadEvent);
        reactor->handle_events(reactor, 100);
    }
    return 0;
}
