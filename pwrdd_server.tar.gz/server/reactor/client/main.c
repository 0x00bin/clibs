#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "reactor.h"
#include "client.h"
#include "address.h"
#include "connection.h"

void onconnection(connection_t* connection) {
    printf("onconecton\n");
    connection->send(connection, "test msg\r\n", 10);
}

void onmessage(connection_t* connection, struct circle_buffer* buffer, void* ptr) {
    printf("onmessage\n");
}

int main(int argc, char ** argv)
{
    if (argc < 3)
    {
        fprintf(stderr, "usage: %s ip port\n", argv[0]);
        return 0;
    }

    reactor_t*  reactor  = reactor_create(10); 
    client_t*   client   = new_client(reactor);
    address_t  address;
    if ( !address_init(&address, atoi(argv[2]), argv[1]) ) {
        printf("address init error:%s", strerror(errno));
    }
    client->onmessage    = onmessage;
    client->onconnection = onconnection;
    if (!client->connect(client, &address) )
    {
        fprintf(stderr, "connect remote server failed\n");
        return 0;
    }

    while (1) {
        reactor->handle_events(reactor, 100); 
    }
    return 0;
}
