
./client 127.0.0.1 8889 1 > t.log&
./client 127.0.0.1 8889 2 > t.log&
./client 127.0.0.1 8889 3 > t.log&
./client 127.0.0.1 8889 4 > t.log&
./client 127.0.0.1 8889 5 > t.log&
./client 127.0.0.1 8889 6 > t.log&
./client 127.0.0.1 8889 7 > t.log&
./client 127.0.0.1 8889 8 > t.log&
./client 127.0.0.1 8889 9 > t.log&
./client 127.0.0.1 8889 10 > t.log&

