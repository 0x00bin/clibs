#pragma once

#include "handler.h"
struct epoller_t;
struct hash_table_t;
typedef struct reactor_t {
    int (*register_handler) (struct reactor_t* this, handler_t* handler, event_t e);
    int (*remove_handler)   (struct reactor_t* this, handler_t* handler);
    int (*handle_events)    (struct reactor_t* this, int timeout); 

    struct epoller_t* epoller_; // epoll
   // handler_t* handlers_;
    struct hash_table_t* handlers_; // fd => handler_t*
} reactor_t;

reactor_t* reactor_create(int maxsize);
