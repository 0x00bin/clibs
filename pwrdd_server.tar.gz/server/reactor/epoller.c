#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/epoll.h>

#include "epoller.h"
#include "handler.h"
//#include "uthash/uthash.h"
#include "hash.h"

int epoller_wait_events(epoller_t* this, hash_table_t* handlers, int timeout)//handler_t* handlers, int timeout)
{
    struct epoll_event events[this->fd_nums];

    int num = epoll_wait(this->epfd, events, this->fd_nums, timeout);
    if (num <= 0 ) {
        return num; 
    }
    printf("events:%d\n", num);
    for(int i = 0; i < num; ++i) {
        int fd = events[i].data.fd;
        handler_t* handler = handlers->find(handlers, fd);
        //HASH_FIND_INT(handlers, &fd, handler);
        assert(handler != NULL);
        struct epoll_event *ev = &events[i];
        if ((ev->events & EPOLLERR) || (ev->events & EPOLLHUP) ) {
            printf("onerror: %d\n", fd);
            handler->onerror(handler);
            handlers->print(handlers);
        } else {
            if (ev->events & EPOLLIN) {
                printf("onread: %d\n", fd);
                handler->onread(handler);
                handlers->print(handlers);                
            }

            if (ev->events & EPOLLOUT) {
                printf("onwrite:%d\n", fd);
                handler->onwrite(handler);
            }
        }
    }
    return num;
}

int epoller_register_event(epoller_t* this, int fd, event_t e)
{
    struct epoll_event ev;
    ev.data.fd = fd;
    ev.events  = 0;
    if (e & ReadEvent) {
        ev.events |= EPOLLIN;
    }

    if (e & WriteEvent) {
        ev.events |= EPOLLOUT;        
    }
    ev.events |= EPOLLONESHOT; // ???

    if (epoll_ctl(this->epfd, EPOLL_CTL_MOD, fd, &ev) != 0) {
        if (errno == ENOENT) {
            printf("errno == ENOENT\n");
            if ( epoll_ctl(this->epfd, EPOLL_CTL_ADD, fd, &ev) !=0) {
                printf("err:%d\n", errno);
                return -errno; // ???
            }
            this->fd_nums++;
        }
    }
    return 0;
}

int epoller_remove_event(epoller_t* this, int fd)
{
    struct epoll_event ev;
    if (epoll_ctl(this->epfd, EPOLL_CTL_DEL, fd, &ev) != 0) {
        return -errno;
    }
    this->fd_nums--;
    
    return 0;
}

epoller_t* epoller_create(int maxsize)
{
    printf("epoller create\n");
    int fd = epoll_create(maxsize);
    if (fd == -1){
        return NULL;
    }
    epoller_t* epoller = malloc(sizeof(epoller_t));
    epoller->epfd    = fd;
    epoller->fd_nums = 0;
    epoller->wait_events    = epoller_wait_events;
    epoller->register_event = epoller_register_event; 
    epoller->remove_event   = epoller_remove_event;

    return epoller;
}
