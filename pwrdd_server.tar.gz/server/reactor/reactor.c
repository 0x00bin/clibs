#include <stdio.h>
#include <stdlib.h>

#include "reactor.h"
#include "epoller.h"
#include "hash.h"

int reactor_register_handler(reactor_t* this, handler_t* handler, event_t e)
{
    int fd = handler->handle;
    handler_t* find;
    find = this->handlers_->find(this->handlers_, fd);
    if (find == NULL) {
        this->handlers_->add(this->handlers_, fd, handler);
        printf("handler add.%d\n", fd);
    } else {
    }

    return this->epoller_->register_event(this->epoller_, fd, e);
}

int reactor_remove_handler(reactor_t* this, handler_t* handler)
{
    int fd = handler->handle;
    this->handlers_->del(this->handlers_, fd);
    this->epoller_->remove_event(this->epoller_, fd);
}

int reactor_socketevents(reactor_t* this, int timeout)
{
    return this->epoller_->wait_events(this->epoller_, this->handlers_, timeout);
}

reactor_t* reactor_create(int maxsize)
{
    reactor_t* reactor = malloc(sizeof(reactor_t));
    reactor->register_handler = reactor_register_handler;
    reactor->remove_handler   = reactor_remove_handler;
    reactor->handle_events    = reactor_socketevents;
    reactor->handlers_        = hash_table_create(maxsize);    // NULL;
    // new epoll
    reactor->epoller_         = epoller_create(maxsize);
    // init 
    return reactor;
}

