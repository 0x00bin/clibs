#pragma once

#include <inih/ini.h>
#include <stdbool.h>

#define CORE_MODS_MAX 100
typedef struct configure_server {
	char  *ip;
	int   port;
	char  *work_dir;
	_Bool daemon;
	char  *pid;
	char  *mods_dir;
    int   mods_num;
	char  *core_mods[CORE_MODS_MAX];
}configure_server_t;

#define OTHERS_MAX 10
typedef struct configure_log {
	char *log_dir;
	char *default_level;
	char *default_output;
	char *bin;
	char *cycle;
	int  count;
	char *others[OTHERS_MAX];
}configure_log_t;

int configure_init(const char* file);

void configure_clean();

struct configure_server *get_configure_server();

struct configure_log *get_configure_log();

void display_configure();

