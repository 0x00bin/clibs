#pragma once

/**
 * @brief 运行日志服务模块
 * @param dir 日志写入的路径名
 * @param default_level 默认日志级别
 * @param default_type  默认日志类型
 * @return void
 */
void log_service_run(const char* dir, const char* default_level, const char* default_type);
