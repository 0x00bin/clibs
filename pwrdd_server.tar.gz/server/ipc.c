#include "ipc.h"
#include <stdio.h>
#include <stdlib.h>


struct modipc_t *alloc_a_modipc()
{
	struct modipc_t *modipc;
	if (NULL == (modipc=malloc(sizeof(struct modipc_t))))
		return NULL;

	return modipc;
}

static int mod_start()
{
	printf("mod_start\n");
	return 0;
}

static int mod_stop()
{
	printf("mod_stop\n");
	return 0;
}

int handle_protocol (struct modipc_t *this, mod_command_t mod_command)
{
	protocol_callback func;

	switch (mod_command) {
	case MOD_COMMAND_START:
		func = mod_start;
		break;
	case MOD_COMMAND_STOP:
		func = mod_stop;
		break;
	default:
		return -1;
	}

	return func();
}
