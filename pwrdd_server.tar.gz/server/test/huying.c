#include "huying.h"
#include <ipc.h>
#include <assert.h>
#include <configure.h>

void hy_test_string_lenth(void)
{
	char* s = "abcdefg";
	int len = strlen(s);
	CU_ASSERT_EQUAL(len, 7);
	
}

struct modipc_t *modipc;

void hy_test_ipc_callback(void)
{
	CU_TEST(modipc->handle_protocol(modipc, MOD_COMMAND_START) == 0);
	CU_TEST(modipc->handle_protocol(modipc, MOD_COMMAND_STOP) == 0);
	CU_TEST(modipc->handle_protocol(modipc, 5) == -1);
}

void hy_test_configure(void)
{
	struct configure_server_t    *server=get_configure_server();
	struct configure_log_t       *log=get_configure_log();
	//struct configure_logrotate_t *logrotate=get_configure_logrotate();

	CU_ASSERT_PTR_NOT_NULL(server);
	CU_ASSERT_PTR_NOT_NULL(server->ip);
	CU_TEST(server->port > 0);
	CU_ASSERT_PTR_NOT_NULL(server->work_dir);
	CU_ASSERT_PTR_NOT_NULL(server->daemon);
	CU_ASSERT_PTR_NOT_NULL(server->pid);
	CU_ASSERT_PTR_NOT_NULL(server->mods_dir);
	CU_ASSERT_PTR_NOT_NULL(server->core_mods);

	CU_ASSERT_PTR_NOT_NULL(log);
	//CU_ASSERT_PTR_NOT_NULL(log->sock_file);
	//CU_TEST(log->bufsize > 0);
	CU_ASSERT_PTR_NOT_NULL(log->default_level);

	CU_ASSERT_PTR_NOT_NULL(log);
	CU_ASSERT_PTR_NOT_NULL(log->bin);
	CU_ASSERT_PTR_NOT_NULL(log->log_dir);
	CU_ASSERT_PTR_NOT_NULL(log->cycle);
	CU_TEST(log->count > 0);
	CU_ASSERT_PTR_NOT_NULL(log->others);

}

int hy_suite_success_init(void)
{
	modipc = alloc_a_modipc();

	assert(modipc != NULL);

	modipc->mod_name=NULL;

	modipc->socketpair_main = 0;
	modipc->socketpair_mod = -1;

	modipc->handle_protocol = handle_protocol;

	configure_init("../configure.ini");

	return 0;
}

int hy_suite_success_clean(void) 
{
	return 0;
}

CU_TestInfo hy_testcase[] = {
	{"test_for_lenth", hy_test_string_lenth},
	{"test_ipc_callback", hy_test_ipc_callback},
	{"test_configure", hy_test_configure},
	CU_TEST_INFO_NULL
};

