#pragma once
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#include <CUnit/Basic.h>
#include <CUnit/Console.h>
#include <CUnit/CUnit.h>
#include <CUnit/TestDB.h>

#include <stdbool.h>



CU_TestInfo xb_testcase[100];

int xb_suite_success_init(void);

int xb_suite_success_clean(void);
