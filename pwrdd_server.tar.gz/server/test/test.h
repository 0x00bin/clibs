#pragma once

extern int add_tests(void);
