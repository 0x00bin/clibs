#pragma once
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include <CUnit/Basic.h>
#include <CUnit/Console.h>
#include <CUnit/CUnit.h>
#include <CUnit/TestDB.h>


CU_TestInfo hy_testcase[100];

int hy_suite_success_init(void);

int hy_suite_success_clean(void);
