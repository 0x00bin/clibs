#include "huying.h"
#include "xianbin.h"
#include "test.h"


CU_SuiteInfo suites[] = {
	{"huying",  hy_suite_success_init, hy_suite_success_clean, hy_testcase},
	{"xianbin", xb_suite_success_init, xb_suite_success_clean, xb_testcase},
	CU_SUITE_INFO_NULL
};

int add_tests(void) {

	assert(NULL != CU_get_registry());
	assert(!CU_is_test_running());

	if (CUE_SUCCESS != CU_register_suites(suites)) {
		exit(EXIT_FAILURE);
	}
	return 0;
}
