#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#include <CUnit/Basic.h>
#include <CUnit/Console.h>
#include <CUnit/CUnit.h>
#include <CUnit/TestDB.h>
#include "test.h"

int
main() 
{
	if (CU_initialize_registry()) {
		fprintf (stderr, " Initialization of Test Registry failed. ");
		exit (EXIT_FAILURE);
	}

	add_tests();

	/*
	   CU_set_output_filename("TestMax");
	   CU_list_tests_to_file();
	   CU_automated_run_tests();
	   */

	CU_basic_set_mode(CU_BRM_VERBOSE);
	CU_basic_run_tests();

	/*
	   CU_console_run_tests();
	   */

	CU_cleanup_registry();

	return CU_get_error();

}
