#include "xianbin.h"
#include "log.h"
#include "pwrd_socket.h"
#include "log_list.h"
#include "circle_buffer.h"
#include <unistd.h>

void xb_test_string_lenth(void)
{
	char* s = "abcdefg";
	int len = strlen(s);
	CU_ASSERT_EQUAL(len, 7);
	//CU_ASSERT_TRUE(dd());
	//CU_ASSERT_FALSE(dd());
	
}

void test_log(void) {
    const char* fname = "./log_test.log";
    log_t* log = log_create(fname, LOG_FILE, LOG_DEBUG, true);
    CU_ASSERT_NOT_EQUAL(log, NULL);
    CU_ASSERT_EQUAL(log->type, LOG_FILE);
    CU_ASSERT_EQUAL(log->level, LOG_DEBUG);

    //CU_ASSERT_NOT_EQUAL(log->outer->mutex, NULL);
    char msg[16] = "testmsg";
    log->write(log, msg, strlen(msg));
    //CU_ASSERT_EQUAL(log->outer->bytes, strlen(msg));

    CU_ASSERT_EQUAL(access(fname, F_OK), 0);
    log->close(log);
    
    FILE* f = fopen(fname, "r");
    CU_ASSERT_NOT_EQUAL(f, NULL);

    char contents[16];
    CU_ASSERT_NOT_EQUAL(fgets(contents, 16, f), NULL);
    
    CU_ASSERT_EQUAL(strcmp(contents, msg), 0);
    fclose(f);  
    //CU_ASSERT_EQUAL(log->outer->mutex, NULL);
    //CU_ASSERT_EQUAL(log->outer->file, NULL);

    CU_ASSERT_EQUAL(unlink(fname), 0);
}

void test_log_list(void) 
{    
    log_list_t* list = log_list_create();
    list->add(list, "test1", LOG_FILE, LOG_DEBUG);
    log_node_t* log_node = list->find(list,"test1");
    CU_ASSERT_NOT_EQUAL(log_node, NULL);
    log_node->write(log_node->log, "test123", 7);
    
    list->add(list, "test2", LOG_STDOUT, LOG_DEBUG);
    log_node_t* log_node2 = list->find(list,"test2");
    CU_ASSERT_NOT_EQUAL(log_node2, NULL);
    log_node2->write(log_node2->log, "test2 345", 9);

    CU_ASSERT_EQUAL(log_node->log->type, LOG_FILE);
    CU_ASSERT_EQUAL(strcmp(log_node->name, "test1"), 0);     
    list->del(list,log_node);
    list->del(list,log_node2);
    log_node_t* log_node1 = list->find(list, "test1");
    CU_ASSERT_EQUAL(log_node1, NULL);
    CU_ASSERT_EQUAL(unlink("test1"), 0);
     
}

void test_pwrd_unix_listerner() 
{
    const char* fname = "/tmp/test.sock";
    int sock = pwrd_unix_listerner(fname, false);
    CU_ASSERT_NOT_EQUAL(sock, -1);
    close(sock);
    unlink(fname);
}

void test_circle_buffer() {
    int buffsize = 1000;
    struct circle_buffer * buff = new_circle_buffer(buffsize);
    
    CU_ASSERT_EQUAL(buff->used(buff), 0);
    CU_ASSERT_EQUAL(buff->free(buff), buffsize);
    
    char data[buffsize];
    bzero(data, buffsize);
    
    
    // test add addn
    char str[] = "1234567890"; // 10
    int len = strlen(str);
    CU_ASSERT_EQUAL(buff->add(buff, str), len); 
    CU_ASSERT_EQUAL(buff->find(buff, "a"), -1);
    CU_ASSERT_EQUAL(buff->find(buff, "abc"), -1);    

    CU_ASSERT_EQUAL(buff->find(buff, "789"), 7-1);
    
    printf("\ndata:%s,strlen:%d,len:%d\n", data, strlen(data), len);
    
    CU_ASSERT_EQUAL(buff->used(buff), len);
    CU_ASSERT_EQUAL(buff->free(buff), buffsize - len);

    int add_len = len/2;
    CU_ASSERT_EQUAL(buff->addn(buff, str, add_len), add_len);
    
    // test drop get
    CU_ASSERT_EQUAL(buff->drop(buff, add_len), add_len);
    
    CU_ASSERT_EQUAL(buff->get(buff, data, len), len);
    printf("\ndata:%s,strlen:%d,len:%d\n", data, strlen(data), len);
    CU_ASSERT_EQUAL(strlen(data), len);        
    
    // test empty
    CU_ASSERT_EQUAL(buff->used(buff), 0);
    CU_ASSERT_EQUAL(buff->free(buff), buffsize);

    // create file
    const char* fname = "./cb_test.tmp";
    FILE* file = fopen(fname, "w+"); 
    if (file == NULL) {
        printf("file open error. errno:%s", strerror(errno));
    }
    setlinebuf(file);
    int file_len = 990;
    char a = 'a';
    for(int i = 1; i <= file_len; ++i) {        
        fwrite(&a, sizeof(char), 1, file);
    }
    fflush(file);
    int fd = fileno(file);
    
    // test add_from_fd
    rewind(file);
    int flen = buff->add_from_fd(buff, fd);
    if (flen == -1) {
        printf("\nerr:%s\n", strerror(errno));
    }
    printf("\nfd:%d,flen:%d, file_len:%d\n",fd, flen, file_len);

    CU_ASSERT_EQUAL(flen, file_len);    
    CU_ASSERT_EQUAL(buff->used(buff), file_len);
//    CU_ASSERT_EQUAL(buff->free(buff), buffsize);
    
    bzero(data, buffsize);

    char cmpstr[] = "aaa";
    CU_ASSERT_EQUAL(buff->get(buff, data, strlen(cmpstr)), strlen(cmpstr));    
    CU_ASSERT_EQUAL(buff->used(buff), file_len - strlen(cmpstr));
    //printf("data:%s,cmpstr:%s", data, cmpstr);
    CU_ASSERT_EQUAL(strcmp(data, cmpstr), 0);
    int free_space = buff->free(buff);
    CU_ASSERT_NOT_EQUAL(free_space, 0);
    char* str1 = malloc(free_space);
    memset(str1, 'A', free_space);
    
    buff->addn(buff, str1, free_space);
    free(str1);

    // test is full
    CU_ASSERT_EQUAL(buff->used(buff), buffsize);
    CU_ASSERT_EQUAL(buff->free(buff), 0);
    
    // test is full add return 0    
    CU_ASSERT_EQUAL(buff->add(buff, str), 0);
     
    char str2[buffsize];
    bzero(str2, buffsize);
    CU_ASSERT_EQUAL(buff->get(buff, str2, buffsize), buffsize);
    
    // is empty    
    CU_ASSERT_EQUAL(buff->used(buff), 0);
    CU_ASSERT_EQUAL(buff->free(buff), buffsize);

    // empty is get return 0
    CU_ASSERT_EQUAL(buff->get(buff, str2, 1), 0);
   
    int str3_len = 100;
    char str3[str3_len];
    char str4[str3_len];
    memset(str3, 'A', str3_len);
    memset(str4, 'B', str3_len);
    int ret3 = 0;
    int last_i = 0;
    for(int i = 1; i < str3_len; ++i) {
        if (i % 2 == 0) {
            ret3 = buff->addn(buff, str4, i);            
        } else {
            ret3 = buff->addn(buff, str3, i);
        }
        
       // printf("\ni:%d, ret3:%d\n", i, ret3);
        if (ret3  == 0) {
            last_i = i - 1;
            break;
        } else {
           // buff->addn(buff, "\r\n", 2);
        }
        CU_ASSERT_EQUAL(ret3, i);
    }
    for(int i = 1; i <= last_i; ++i){
        bzero(str3, str3_len);
        //int cr_cn = buff->find(buff, "\r\n");
        
        CU_ASSERT_EQUAL(buff->get(buff, str3, i), i);
        printf("%s %d\n", str3, strlen(str3));
    }
    printf("used:%d, free:%d\n", buff->used(buff),buff->free(buff));

    char crcn_buff[1024];
    bzero(crcn_buff, 1024);
    buff->add(buff, "abc\r\n");
printf("used:%d, free:%d\n", buff->used(buff),buff->free(buff));
    buff->add(buff, "123456789\r\n");  
printf("used:%d, free:%d\n", buff->used(buff),buff->free(buff));
    int cr_cn = buff->find(buff, "\r\n");
    
    buff->get(buff, crcn_buff, cr_cn + 2);    
    printf("cr_cn:%d, strlen:%d, get:'%s'\n", cr_cn, strlen(crcn_buff), crcn_buff);
    cr_cn = buff->find(buff, "\r\n");
    bzero(crcn_buff, 1024);
    buff->get(buff, crcn_buff, cr_cn + 2);
    printf("cr_cn:%d, strlen:%d, get:'%s'\n", cr_cn, strlen(crcn_buff), crcn_buff);
    // clear
    buff->clean(buff); 
    fclose(file);        
    // del fname
    unlink(fname);
}


int
xb_suite_success_init(void)
{
	return 0;
}

int
xb_suite_success_clean(void) 
{
	return 0;
}

CU_TestInfo xb_testcase[] = {
	{"test_for_lenth", xb_test_string_lenth},
    {"test_log", test_log},
    {"test_log_list", test_log_list},
    {"test_pwrd_unix_listerner", test_pwrd_unix_listerner},
    {"test_circle_buffer", test_circle_buffer},
    CU_TEST_INFO_NULL
};


