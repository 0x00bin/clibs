#pragma once

#include "libs/log.h"
#include "uthash/uthash.h"
typedef struct log_node_t {
    char name[32]; // key
    log_t* log; 
    void (*write)(log_t* log, const char* msg, size_t len);
    UT_hash_handle hh;
} log_node_t;

typedef struct log_list_t {
    log_node_t* head; /* list head node private */

    /**
     * @brief 添加一个新的日志节点到日志列表
     * @param name  节点名称
     * @param type  日志类型
     * @param level 日志级别
     * @return log_node_t 新添加的日志节点对象
     */
    log_node_t* (*add) (struct log_list_t* this, const char* name, log_type type, log_level level);

    /**
     * @brief 查找一个日志节点
     * @param name 查找的日志节点名字
     * @return log_node_t 找到的日志节点, 没找到返回NULL
     */
    log_node_t* (*find)(struct log_list_t* this, const char* name);

    /**
     * @brief 删除一个日志节点
     * @param node 删除的节点
     * @retuan void
     */
    void        (*del) (struct log_list_t* this, log_node_t* node);    
} log_list_t;

/**
 * @brief 创建一个日志列表
 * @return 新建的日志类别对象
 */
log_list_t* log_list_create();
