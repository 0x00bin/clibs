#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include "configure.h"

static struct configure_server *configure_server;
static struct configure_log *configure_log;

int core_mods_no=0;
int others_no=0;
static int handler(void* user, const char* section, const char* name,
		const char* value)
{

#define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
	if (MATCH("server", "ip")) {
		configure_server->ip = strdup(value);
	} else if (MATCH("server", "port")) {
		configure_server->port = atoi(value);
	} else if (MATCH("server", "work_dir")) {
		configure_server->work_dir = strdup(value);
	} else if (MATCH("server", "daemon")) {
		configure_server->daemon = atoi(value) ? true : false;
	} else if (MATCH("server", "pid")) {
		configure_server->pid = strdup(value);
	} else if (MATCH("server", "mods_dir")) {
		configure_server->mods_dir = strdup(value);
	} else if (MATCH("server", "core_mods")) {
		configure_server->core_mods[core_mods_no++] = strdup(value);
        configure_server->mods_num = core_mods_no;
	} else if (MATCH("log", "default_level")) {
		configure_log->default_level = strdup(value);
	} else if (MATCH("log", "default_output")) {
		configure_log->default_output = strdup(value);
	} else if (MATCH("log", "bin")) {
		configure_log->bin = strdup(value);
	} else if (MATCH("log", "log_dir")) {
		configure_log->log_dir = strdup(value);
	} else if (MATCH("log", "cycle")) {
		configure_log->cycle = strdup(value);
	} else if (MATCH("log", "count")) {
		configure_log->count = atoi(value);
	} else if (MATCH("log", "others")) {
		configure_log->others[others_no++] = strdup(value);
	} else {
		return -1;  /* unknown section/name, error */
	}
	return 0;
}

int configure_init(const char* file)
{
	configure_server    = malloc(sizeof(struct configure_server));
	configure_log       = malloc(sizeof(struct configure_log));

	if (ini_parse(file, handler, NULL) < 0)
		return -1;

	return 0;
}

void configure_clean()
{
	return;
}

struct configure_server *get_configure_server()
{
	return configure_server;
}

struct configure_log *get_configure_log()
{
	return configure_log;
}

void display_configure()
{
	printf("\n[server]\n");
	printf("ip = %s\n", configure_server->ip);
	printf("port = %d\n", configure_server->port);
	printf("work_dir = %s\n", configure_server->work_dir);
	printf("daemon = %d\n", configure_server->daemon);
	printf("pid = %s\n", configure_server->pid);
	printf("mods_dir = %s\n", configure_server->mods_dir);
	for (int i=0; i<CORE_MODS_MAX;++i)
		if (configure_server->core_mods[i])
			printf("core_mods[%d] = %s\n", i, configure_server->core_mods[i]);

	printf("\n[log]\n");
	printf("log_dir = %s\n", configure_log->log_dir);
	printf("default_level = %s\n", configure_log->default_level);
	printf("default_output = %s\n", configure_log->default_output);
	printf("bin = %s\n", configure_log->bin);
	printf("cycle = %s\n", configure_log->cycle);
	printf("count = %d\n", configure_log->count);
	for (int i=0; i<OTHERS_MAX;++i)
		if (configure_log->others[i])
			printf("others[%d] = %s\n", i, configure_log->others[i]);
}
