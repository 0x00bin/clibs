#pragma once

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

struct circle_buffer_t {

	char *sp;	/* start pointer */
	char *ep;	/* end pointer */
	char *csp;	/* current start pointer */
	char *cep;	/* current end pointer */
	char *buffer;	/* 数据区域 */
	int  size;	/* 数据区域大小 */
	bool isfull;

	
	/**
	 * @brief 初始化一个circle buffer
	 */
	void (*init)  (struct circle_buffer_t *this);

	/**
	 * @brief 重置circle buffer
	 */
	void (*reset) (struct circle_buffer_t *this);

	/**
	 * @brief 删除当前buffer
	 */
	void (*clean) (struct circle_buffer_t *this);

	/**
	 * @brief 往circle buffer中添加字符串str
	 *
	 * @return 成功返回添加的数据的大小
	 * 失败返回-1
	 */
	ssize_t (*add)   (struct circle_buffer_t *this, const char *str);

	/**
	 * @brief 往circle buffer中添加 len长度 字符串str
	 *
	 * @return 成功返回添加的数据的大小
	 * 失败返回-1
	 */
	ssize_t (*addn)  (struct circle_buffer_t *this, const char *str, size_t len);

	/**
	 * @brief 读取fd数据往circle buffer中,读取的大小为circle buffer的最大空闲区域
	 *
	 * @return 成功返回添加的数据的大小
	 * 失败返回-1
	 */
	ssize_t (*add_from_fd)  (struct circle_buffer_t *this, ssize_t fd);

	/**
	 * @brief 从fd读取len长度数据到circle buffer中
	 *
	 * @return 成功返回添加的数据的大小
	 * 失败返回-1
	 */
	ssize_t (*addn_from_fd)  (struct circle_buffer_t *this, size_t fd, size_t len);

	/**
	 * @brief 从circle buffer中获取len大小放入str中, 并释放circle buffer空间
	 *
	 * @return 成功返回读取的数据的大小
	 * 失败返回-1
	 */
	ssize_t (*get)  (struct circle_buffer_t *this, char *str, size_t len);

	/**
	 * @brief 返回当前circle buffer中使用的大小
	 */
	size_t  (*used) (struct circle_buffer_t *this);

	/**
	 * @brief 返回当前circle buffer中空闲的大小
	 */
	size_t  (*free) (struct circle_buffer_t *this);

	/**
	 * @brief 删除当前circle buffer中的len长度的数据
	 *
	 * @return 成功返回删除长度
	 * -1 失败
	 */
	ssize_t (*drop) (struct circle_buffer_t *this, size_t len);
};


/**
 * @brief 往circle buffer中添加 len长度 字符串str
 *
 * @return 成功返回circle buffer指针
 * 失败返回NULL
 */
struct circle_buffer_t *alloc_circle_buffer(const int len);

