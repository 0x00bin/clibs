#include <stdlib.h>
#include <strings.h>
#include <stdbool.h>

#include "circle_buffer.h"

typedef struct circle_buffer_t circle_buffer_t;
struct circle_buffer_t *alloc_circle_buffer(const int len) 
{
    circle_buffer_t* buff = malloc(sizeof(circle_buffer_t));
    bzero(buff, sizeof(circle_buffer_t));
    buff->size   = len;

    char* buffer = malloc(len);
    buff->buffer = buffer;

    buff->init   = circle_buffer_init;
}

void circle_buffer_init(circle_buffer_t* this)
{         
    this->sp   = this->buffer;
    this->csp  = this->buffer;
    this->cep  = this->buffer;
    this->ep   = this->buffer + this->size;
    this->full = false;
}

void circle_buffer_reset(circle_buffer_t* this)
{
    this->csp  = this->sp;
    this->cep  = this->sp;
    this->full = false;
}

void circle_buffer_clean(circle_buffer_t* this) 
{
    if (this->buffer) {
        free(this->buffer);
    }
    free(this);
}    

void circle_buffer_used(circle_buffer_t* this)
{
    if (this->csp < this->cep) {
        return this->cep - this->csp;        
    } else if (this->csp - this->cep) {
        return this->size - (this->csp - this->cep);        
    }

    return this->full? this->size:0;
}

void circle_buffer_free(circle_buffer_t* this)
{
    return this->size - this->used(this);
}

void circle_buffer_check_full(circle_buffer_t* this)
{
    if (this->csp == this->cep) {
        this->full = true;
    }
}

ssize_t circle_buffer_add_from_fd (circle_buffer_t* this, ssize_t fd)
{
    if (this->free(this) == 0) {
        return 0;
    }

    ssize_t n = n1 = 0;
    /* 空闲空间非连续 */
    if (this->csp <= this->cep) {
        n = read(fd, this->cep, this->ep - this->cep);
        if (n <= 0) {
            return n;
        } else if (n < this->ep - this->cep) {
            this->cep = this->cep + n;
            return n;
        }
        this->cep = this->sp;
    }

    /* 空闲空间连续 */
    if ((n1 = read(fd, this->cep, this->csp - this->cep)) < 0) {
        return n1; // 上面读了一次，后一次出错，是否要返回n？
    }

    this->cep = this->cep + n1;

    circle_buffer_check_full(this);

    return n + n1;
}

ssize_t circle_buffer_addn(circle_buffer_t* this, const char* str, size_t len)
{    
    if (str == NULL) {
        return 0;
    }

    if (len > this->free(this) ) {
        return 0;
    }
    const char* p = str;
    ssize_t n = len;

    // buffer is Non-continuous space
    if (this->csp <= this->cep) {
        if (n <= this->ep - this->cep) { // 末尾的连续空间已满足
            memcpy(this->cep_, p, n);
            this->cep_ = (n == this->ep - this->cep)? this->sp: this->cep + n;
            circle_buffer_check_full(this);
            return len;
        }

        // 末尾的连续空间不满足先copy 一部分到末尾连续空间
        int cpy_len = this->ep - this->cep;
        memcpy(this->cep, p, cpy_len);
        p = p + cpy_len;
        n = n - cpy_len;
        this->cep = this->sp;
    }
    memcpy(this->cep, p, n);
    this->cep = this->cep + n;
    circle_buffer_check_full(this);    

    return len;
}

ssize_t circle_buffer_add(circle_buffer_t* this, const char* str)
{
    return this->addn(this, str, strlen(str));
}

ssize_t circle_buffer_drop(circle_buffer_t* this, size_t len)
{
    if (len <=0) {
        return 0;
    }

    if (len > this->used(this)) {
        return 0;
    }
    ssize_t n = len;
    if (this->csp >= this->cep) {
        if (n <= this->ep - this-> csp) {
            this->csp = (n == this->ep - this->csp)? this->sp : this->csp + n;
            circle_buffer_check_full(this);

            return len;
        }
        n = n - (this->ep - this->csp);
        this->csp = this->sp;
    }

    this->csp = this->csp + n;
    circle_buffer_check_full(this);

    return len;
}

ssize_t circle_buffer_get (circle_buffer_t* this, char* dest, size_t len)
{
    if (len <= 0) {
        return 0;
    }
    ssize_t used = this->used(this);
    if (len > used) {
        len = used;
    }
    bzero(dest, len);

    /* 使用空间非连续 */
    ssize_t n = len;
    char *p = dest;
    char* data = this->csp;
    if (data >= this->cep) {
        if (n <= this->ep - data) {
            memcpy(dest, data, n);
            return len;
        }
        ssize_t cpy_len = this->ep - data;
        memcpy(dest, data, cpy_len);
        p = p + cpy_len;
        n = n - cpy_len;
        data = this->sp;
    }
    /* 使用空间连续 */
    memcpy(p, data, n);
    return len;
}

