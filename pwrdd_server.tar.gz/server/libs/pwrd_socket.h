#ifndef PWRD_SOCKET_HPP
#define PWRD_SOCKET_HPP

/**
  -std=c99
*/
#include <sys/un.h>
#ifdef __cplusplus
extern "C"
{
#endif
/**
 * @brief  启动一个unix socket 服务
 *
 * @param sock_file unix域文件
 * @param type
 * true  建立一个tcp的socket
 * false 建立一个UDP的socket
 *
 * @return 
 */
extern int pwrd_unix_listerner(const char *sock_file, _Bool istcp);

/**
 * @brief  绑定一个udp unix域
 *
 * @param sock_file
 * @param servaddr
 *
 * @return 
 */
//extern int pwrd_unix_connect(const char *sock_file, _Bool noblock);
extern int pwrd_unix_bind(const char *sock_file, struct sockaddr_un* servaddr);
/**
 * @brief  启动一个socket 服务
 *
 * @param ip
 * @param port
 * @param istcp
 * true  建立一个tcp的socket
 * false 建立一个UDP的socket
 *
 * @return 
 */
extern int pwrd_listerner(const char *ip, const int port, _Bool istcp);


/**
 * @brief accpet一个连接 并返回ip和端口
 *
 * @param sockfd
 * @param ip
 * @param port
 *
 * @return 
 */
extern int pwrd_accept(const int sock, char* ip, int* port);


/**
 * @brief *  连接一个tcp服务器
 *
 * @param ip
 * @param port
 * @param block
 *
 * @return 
 */
extern int pwrd_connect(const char *ip, const int port, _Bool noblock);

/**
 * @brief 设置o_noblock socket
 *
 * @param sockfd
 *
 * @return 
 */
extern int pwrd_set_noblock(const int sock);

/**
 * @brief 设置close_on_exec socket
 *
 * @param sockfd
 *
 * @return 
 */
extern int pwrd_set_close_on_exec(const int sock);

#ifdef __cplusplus
}
#endif

#endif
