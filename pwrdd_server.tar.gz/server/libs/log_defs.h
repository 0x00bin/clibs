#pragma once

typedef enum {
    LOG_DEBUG,    
    LOG_INFO,
    LOG_NOTICE,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL,
    LOG_UNKNOWN
} log_level;

typedef enum {
    LOG_NULL, //close log output            
    LOG_STDOUT,
    LOG_FILE,
    LOG_UDP
} log_type;
