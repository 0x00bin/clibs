#include "hash.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct test_t {
    int a;
} test_t;
test_t* test_create(int a) {
    test_t* t = malloc(sizeof(test_t));
    t->a = a;
    return t;
}
int main()
{
    hash_table_t* ht = hash_table_create(30);;
        
    for(int i = 0; i < 30; ++i) {
        ht->add(ht, i, test_create(i));
    }

    ht->print(ht);

    for(int i = 10; i < 20; ++i) {
        ht->del(ht, i);        
    }
    ht->print(ht);
    printf("find 28 a=%d\n", ((test_t*)(ht->find(ht, 28)))->a);
    return 0;
}
