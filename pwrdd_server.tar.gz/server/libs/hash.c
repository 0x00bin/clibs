#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "hash.h"

typedef struct hash_node_t {
    int   key; // hash key
    void* val; // val ptr
    struct hash_node_t* next; // next ptr
    struct hash_node_t* prev; // prev ptr
} hash_node_t;

void hash_node_init(hash_node_t* this) 
{
    this->key  = -1;
    this->val  = NULL;
    this->next = NULL;
    this->prev = NULL;
}

void hash_node_del(hash_node_t* this) 
{
    if (this->prev != NULL) {
        this->prev->next = this->next;
    }
    if (this->next != NULL) {
        this->next->prev = this->prev;
    }

    free(this);
} 

hash_node_t* hash_node_new(hash_node_t* this, int key, void* val)
{
    hash_node_t* node = malloc(sizeof(hash_node_t));
    node->key   = key;
    node->val   = val;
    node->next  = NULL;
    node->prev  = this;
    if (this != NULL) {
        this->next = node;
    }
    return node;
}

int hash_table_hash(hash_table_t* this, int key)
{
    // hash key to 0 ~ size - 1;
    if (this->size > key) {
        return key;
    }
    return key % this->size;
}

int hash_table_add(hash_table_t* this, int key, void* val) 
{
    int i = hash_table_hash(this, key); 
    if (this->table[i] == NULL) {
        this->table[i] = hash_node_new(NULL, key, val);        
        return i;
    }
     
    hash_node_t* node = this->table[i];
    // TODO 冲突处理
    while(node->next != NULL) {
       node = node->next; 
    }
    hash_node_new(node, key, val);

    return i;
}

hash_node_t* hash_table_find_node(hash_table_t* this, int key)
{
    int i = hash_table_hash(this, key);

    hash_node_t* node = this->table[i];
    while(node != NULL) {        
        if (node->key == key) {
            return node;
        }
        node = node->next;
    }
    return NULL;
}

void* hash_table_find(hash_table_t* this, int key)
{
    hash_node_t* node = hash_table_find_node(this, key);
    if (node != NULL) {
        return node->val;
    }
    return NULL;
}

int hash_table_del(hash_table_t* this, int key) 
{
    hash_node_t* node = hash_table_find_node(this, key);
    if (node == NULL) {
        return -1;
    }
    
    int i = hash_table_hash(this, key);
    if (node == this->table[i]) {
        this->table[i] = node->next;
    }
    hash_node_del(node);
    return i; 
}

void hash_node_print(hash_node_t* this)
{    
    printf("[key=%d, val=%p, next=%p, prev=%p] ", this->key, this->val, this->next, this->prev);
}

void hash_table_print(hash_table_t* this)
{
    hash_node_t* node = NULL;
    printf("\ntables:");
    for(int i = 0; i < this->size; ++i) {
        node = this->table[i];
        printf("\ni=%d ", i);
        while(node != NULL) {
            hash_node_print(node); 
            node = node->next;
        }

        printf("\n");
    }
    printf("\n");
}


hash_table_t* hash_table_create(int size)
{    
    hash_table_t* this = malloc(sizeof(hash_table_t));
    this->table = malloc(sizeof(hash_node_t*) * size);
    this->size  = size;///
    for(int i = 0; i < size; ++i) {
        this->table[i] = NULL;
    }
    this->add   = hash_table_add;
    this->del   = hash_table_del;
    this->find  = hash_table_find;
    this->print = hash_table_print;

    return this;
}

