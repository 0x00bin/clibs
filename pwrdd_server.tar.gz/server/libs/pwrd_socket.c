#include "pwrd_socket.h"

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <limits.h>
#include <fcntl.h>


const int BACKLOG = 5;

int pwrd_unix_listerner(const char *sock_file, _Bool istcp)
{
	struct sockaddr_un addr;
	int sock;
	int type;

	type = istcp ? SOCK_STREAM : SOCK_DGRAM;
    unlink(sock_file);
	bzero(&addr, sizeof(struct sockaddr_un));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, sock_file);
    
	if ((sock = socket(AF_UNIX, type, 0)) < 0)
		return -1;

	if (bind(sock, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) < 0)
		return -1;

	if (istcp && listen(sock, BACKLOG) < 0)
		return -1;

	return sock;

}

int pwrd_unix_bind(const char *sock_file, struct sockaddr_un* servaddr)
{
	struct sockaddr_un addr;
	int sock;
    
	if ((sock = socket(AF_LOCAL, SOCK_DGRAM, 0)) < 0)
		return -1;
    
	bzero(&addr, sizeof(struct sockaddr_un));
	addr.sun_family = AF_LOCAL;
    
    char tmp[] = "/tmp/clisock-XXXXXX";
    mkstemp(tmp);
	strcpy(addr.sun_path, tmp);
//    printf("tmp= %s\n", tmp);        
    bind(sock, (struct sockaddr*) &addr, sizeof(addr));

    bzero(servaddr, sizeof(struct sockaddr_un));
    servaddr->sun_family = AF_LOCAL;
    strcpy(servaddr->sun_path, sock_file);

	return sock;
}

int pwrd_listerner(const char *ip, const int port, _Bool istcp)
{
	struct sockaddr_in addr;
	int sock;
	int type;

	type = istcp ? SOCK_STREAM : SOCK_DGRAM;

	bzero(&addr, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);

	if (inet_pton(AF_INET, ip, &addr.sin_addr) != 1)
		return -1;

	if ((sock = socket(AF_INET, type, 0)) < 0)
		return -1;

	//端口重用
	int on = 1;
	if (setsockopt (sock, SOL_SOCKET, SO_REUSEADDR, (const char *) &on, sizeof(on)) < 0)
		return -1;

	if (bind(sock, (struct sockaddr *) &addr, sizeof(struct sockaddr_in)) < 0)
		return -1;

	if (istcp && listen(sock, BACKLOG) < 0)
		return -1;

	return sock;
}

int pwrd_accept(const int sockfd, char *ip, int *port)
{
	int fd;
	struct sockaddr_in addr;
	socklen_t addrlen;
	addrlen = sizeof(struct sockaddr);

	if ((fd = accept(sockfd, (struct sockaddr *) &addr, &addrlen)) < 0)
		return -1;

	if (inet_ntop(AF_INET,
				&addr.sin_addr, ip, sizeof(struct sockaddr)) == NULL)
		return -1;


	*port = ntohs(((struct sockaddr_in *) &addr)->sin_port);

	return fd;
}

int pwrd_connect(const char *ip, const int port, _Bool noblock)
{
	struct sockaddr_in addr;
	int sock;

	bzero(&addr, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);

	if (inet_pton(AF_INET, ip, &addr.sin_addr) < 0)
		return -1;

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		return -1;

	if (noblock)
		pwrd_set_noblock(sock);

	if (connect(sock, (struct sockaddr *) &addr, sizeof(addr)) < 0)
		return -1;

	return sock;
}

int pwrd_set_noblock(const int sockfd)
{
	int flags;
	flags = fcntl(sockfd, F_GETFL, 0);
	return fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
}

int pwrd_set_close_on_exec(const int sockfd)
{
	int flags;
	if ((flags = fcntl(sockfd, F_GETFD, 0)) < 0)
		return -1;

	if (fcntl(sockfd, F_SETFD, flags | FD_CLOEXEC) == -1)
		return -1;

	return 0;
}
