#ifndef _LOG_H_
#define _LOG_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <pthread.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include "log_defs.h"

typedef struct log_t
{ 
    log_level level; /* log level */
    log_type  type;  /* log type */

    void* outer; /* is log_udp_t OR log_local_t */

    /**
     * @brief 写日志
     * @param 日志信息
     * @param 日志长度
     * @return void
     */
    void (*write)(struct log_t* this, const char* msg, size_t len);

    /**
     * @brief 关闭日志对象
     * @return void
     */
    void (*close)(struct log_t* this);

    /**
     * @brief 设置为默认的日志对象
     * @return void
     */
    void (*set_default)(struct log_t* this);
} log_t;

/**
 * @brief 创建日志对象
 * @param fname  日志文件路径名
 * @param type   日志类型
 * @param level  日志级别
 * @param islock 日志文件是否加锁
 * @return log_t* 返回日志对象
 */
log_t* log_create(const char* fname, log_type type, log_level level, _Bool is_lock);

/**
 * @brief 字符串等级转化为int eg. 'debug' to LOG_DEBUG
 * @param str_level 等级的字符串
 * @return int 日志等级
 */
int log_str2level(const char* level);
int log_str2type (const char* type);
// before calling log_write() must call log->set_default(log)
void log_write( const char* fname, 
                const char* func, 
                const int line,
                log_level level, 
                const char* format, ...);

// use this must log_set_default();
#define DEBUG(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_DEBUG,  FORMAT, ##__VA_ARGS__)
#define INFO(FORMAT, ...)  log_write(__FILE__, __func__, __LINE__, LOG_INFO,  FORMAT, ##__VA_ARGS__)
#define NOTICE(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_NOTICE, FORMAT, ##__VA_ARGS__)
#define WARN(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_WARN, FORMAT, ##__VA_ARGS__)
#define ERROR(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_ERROR, FORMAT, ##__VA_ARGS__)
#define FATAL(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_FATAL, FORMAT, ##__VA_ARGS__)
#define UNKNOWN(FORMAT, ...) log_write(__FILE__, __func__, __LINE__, LOG_UNKNOWN, FORMAT, ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif
