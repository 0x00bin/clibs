#include "log.h"
#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#include <sys/syscall.h>
#define gettid() syscall(__NR_gettid)

#define LOG_LINE_BUF_SIZE 1024
#define LOG_FLUSH_INTERVAL 10 // 30s
static const char* log_level2str[] = {
    "DEBUG",
    "INFO",
    "NOTICE",
    "WARN",
    "ERROR",
    "FATAL",
    "UNKNOWN"
};
static const char* log_type2str[] = {
    "null",
    "stdout",
    "file",
    "udp"
};

log_t* g_log = NULL;

#include "log_msg.h"
#include <sys/un.h>
typedef struct log_udp_t {
    int                sock; //log udp domain sock
    struct sockaddr_un servaddr; // server addr     
    log_msg_t          msg;
} log_udp_t;

typedef struct log_local_t {    
    FILE*  file;
    char   buffer[BUFSIZ];
    size_t bytes; // written bytes
    pthread_mutex_t* mutex;
    time_t last_flush;
} log_local_t;

#include "pwrd_socket.h"
#include <sys/socket.h>
#include <errno.h>

void log_default(log_t* this)
{
    g_log = this;
}

// log udp funcs
void log_udp_close(log_t* this)
{
    if (this == NULL) return;
    if (this->outer) {
        free((log_udp_t*)(this->outer));
    }
    free(this);
}

void log_udp_append(log_t* this, const char* msg, size_t len)
{
    log_udp_t* udp = (log_udp_t*)(this->outer);
    bzero(udp->msg.data, sizeof(udp->msg.data));
    strcpy(udp->msg.data, msg);
    size_t n = sendto(udp->sock, &(udp->msg), sizeof(udp->msg), 0, 
            (struct sockaddr*)&(udp->servaddr), sizeof(udp->servaddr));
    if (n == -1) {
        printf("sendto error%d", errno);
    }
}

log_t* log_udp_create(const char* fname, log_type type, log_level level, _Bool is_lock) 
{
    log_t* this = malloc(sizeof(log_t));
    this->write = log_udp_append;
    this->close = log_udp_close;
    this->set_default = log_default;

    this->level = level;
    this->type  = type;

    log_udp_t* udp = malloc(sizeof(log_udp_t));
    strcpy(udp->msg.name, fname);
    bzero(udp->msg.data, LOG_MSG_DATA_SIZE);
    udp->sock  = pwrd_unix_bind(LOG_UDP_SOCK, &(udp->servaddr));
    
    this->outer = udp;

    return this;
}

// log local funcs
void log_local_flush(log_t* this) 
{
    log_local_t* local = (log_local_t*)(this->outer);
    if (local->file) {
        fflush(local->file);
    }
}

void log_local_close(log_t* this) {
    if (this == NULL) return;

    log_local_flush(this);
    if (this->outer)  {
        log_local_t* local = (log_local_t*)(this->outer); 
        if (local->mutex) {
            pthread_mutex_destroy(local->mutex);
            free (local->mutex);
            local->mutex = NULL;
        }
        if (this->type == LOG_FILE) {
            fclose(local->file);
            local->file = NULL;
        }

        free(local);
        this->outer = NULL;
    }
    free(this);
}

size_t log_local_write(log_t* this, const char* msg, size_t len) {
    return fwrite_unlocked(msg, 1, len, ((log_local_t*)(this->outer))->file); 
}

void log_local_append_unlocked(log_t* this, const char* msg, size_t len) {
    int n = log_local_write(this, msg, len);
    log_local_t* local = (log_local_t*)(this->outer); 
    assert(n == len);
    local->bytes += n;  

    // TODO roll file
    time_t now = time(NULL);
    if (now  - local->last_flush > LOG_FLUSH_INTERVAL) {
        local->last_flush = now;
        log_local_flush(this);
    }
}

void _log_local_append(log_t* this, const char* msg, size_t len) {
    log_local_t* local = (log_local_t*)(this->outer); 
    if (local->mutex) {
        pthread_mutex_lock(local->mutex);
        log_local_append_unlocked(this, msg, len);
        pthread_mutex_unlock(local->mutex);
    } else {
        log_local_append_unlocked(this, msg, len);
    }
}

log_t* log_local_create(const char* fname, log_type type, log_level level, _Bool islock) {     
    if (type == LOG_NULL) { 
        return NULL;
    }

    FILE* file = NULL;
    if (type == LOG_STDOUT) {
        file = stdout;  
    } else {
        file = fopen(fname, "a+");
        if (file == NULL) {
            printf("fopen(%s) is error. in log_local_create()", fname);
            return NULL;
        }
    }

    log_t* this = malloc(sizeof(log_t));
    this->level = level;
    this->type  = type;

    log_local_t* local = malloc(sizeof(log_local_t));
    local->file  = file;
    local->bytes = 0;
    local->mutex = NULL;
    local->last_flush = 0;

    if (islock) {
        local->mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(local->mutex, NULL);
    }

#ifndef _LOG_NOBUFF
    //setbuffer(file, local->buffer, sizeof (local->buffer));
    setlinebuf(file);
#endif
    this->write = _log_local_append;    
    this->close = log_udp_close;
    this->set_default = log_default;

    this->outer = local;

        return this;
}

log_t* log_create(const char* fname, log_type type, log_level level, _Bool islock) 
{
    if (type == LOG_UDP) {
        return log_udp_create(fname, type, level, islock);     
    } else {
        return log_local_create(fname, type, level, islock);
    }
}

void log_write(const char* fname, const char* func, const int line,
        log_level level, const char* format, ...) 
{
    if (g_log == NULL) {
        return;
    }
    if (level < g_log->level) return;

    char buf[LOG_LINE_BUF_SIZE];
    bzero(buf, LOG_LINE_BUF_SIZE);
    char msg[LOG_LINE_BUF_SIZE];
    bzero(msg, LOG_LINE_BUF_SIZE); 

    va_list argv;
    va_start(argv, format);
    vsnprintf(buf, LOG_LINE_BUF_SIZE, format, argv);
    va_end(argv);

    char timebuf[32];
    struct tm tm;
    time_t now = time(NULL);
    localtime_r(&now, &tm);
    strftime(timebuf, sizeof timebuf, "%Y-%m-%d %H:%M:%S", &tm);

    size_t len = sprintf(msg, "%s %s %s [%ld:%s:%s:%d]\n", timebuf, log_level2str[level],
            buf, gettid(), fname, func, line);
    // TODO check file exists.
    g_log->write(g_log, msg, len);
}

int log_str2int(const char* str, const char** array, int len) 
{        
    for (int i = 0; i < len; i++) { 
        if (0 == strcasecmp(array[i], str)) {
            return i;
        }
    }   
    return -1;
}

int log_str2type(const char* type) 
{
    int len = sizeof(log_type2str)/sizeof(log_type2str[0]);
    return log_str2int(type, log_type2str, len);
}

int log_str2level(const char* level)
{    
    int len = sizeof(log_level2str)/sizeof(log_level2str[0]);
    return log_str2int(level, log_level2str, len);
}
