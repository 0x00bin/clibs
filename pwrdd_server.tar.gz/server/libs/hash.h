#pragma once

struct hash_node_t;
typedef struct hash_table_t {
    struct hash_node_t** table; // data table    
    int          size;  // table size;
     
    int   (*add)   (struct hash_table_t* this, int key, void* val); 
    int   (*del)   (struct hash_table_t* this, int key);
    void* (*find)  (struct hash_table_t* this, int key);
    void  (*print) (struct hash_table_t* this);
} hash_table_t;

hash_table_t* hash_table_create(int size);
