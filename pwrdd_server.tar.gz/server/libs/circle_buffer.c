#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <strings.h>
#include <stdbool.h>

#include "circle_buffer.h"

void circle_buffer_init(circle_buffer_t* this)
{         
    this->head   = 0;
    this->tail   = 0;    
}

void circle_buffer_reset(circle_buffer_t* this)
{
    this->init(this);
}

void circle_buffer_clean(circle_buffer_t* this) 
{
    if (this->buffer) {
        free(this->buffer);
    }
    free(this);
}    

size_t circle_buffer_used(circle_buffer_t* this)
{
    return (this->tail - this->head + this->size) % this->size;
}

size_t circle_buffer_free(circle_buffer_t* this)
{
    return this->size - this->used(this) - 1;
}


_Bool circle_buffer_empty(circle_buffer_t* this)
{
    return this->head == this->tail;
}

_Bool circle_buffer_full(circle_buffer_t* this)
{
    return (this->tail + 1) % this->size == this->head;
}

ssize_t circle_buffer_addn_from_fd (circle_buffer_t* this, size_t fd, size_t len)
{
    if (len <= 0) {
        return 0;
    }
    if (circle_buffer_full(this)) {
        return 0;
    }
    
    int space = this->free(this);
    if (len > space) {
        return 0;
    }
    
    char buff[BUFSIZ];
   // char* buff = malloc(len);
    int n = read(fd, buff, len);
    
    if ( n < 0) {
//        free(buff);
        return n;
    }
    ssize_t ret = this->addn(this, buff, n);

  //  free(buff);

    return ret;
}

ssize_t circle_buffer_add_from_fd(circle_buffer_t *this, size_t fd)
{
    return this->addn_from_fd(this, fd, this->free(this));
}

int circle_buffer_ptr_inc(circle_buffer_t* this, int ptr, ssize_t n) {
    return (ptr + n) % (this->size);
}

void circle_buffer_push(circle_buffer_t* this, const char* data, ssize_t len)
{
    memcpy(this->buffer + this->tail, data, len);
    this->tail = circle_buffer_ptr_inc(this, this->tail, len); 
}

ssize_t circle_buffer_addn(circle_buffer_t* this, const char* data, size_t len)
{    
    if (data == NULL) {
        return 0;
    }
    
    if (len > this->free(this) ) {
        return 0;
    }
    
    ssize_t     n = len;
    const char* p = data;
        
    // empty is Non-continuous space 
    // buffer is empty but head is not zero, OR head < tail
    if ( (this->head == this->tail && this->head != 0) || this->head < this->tail) {
        if (n <= this->size - this->tail) { // 末尾的连续空间已满足
            circle_buffer_push(this, p, n);
            return len;
        }
        // 末尾的连续空间不满足先copy 一部分到末尾连续空间        
        int cpy_len = this->size - this->tail;
        circle_buffer_push(this, p, cpy_len);
        p = p + cpy_len;
        n = n - cpy_len;
    }
    circle_buffer_push(this, p, n);

    return len;
}

ssize_t circle_buffer_add(circle_buffer_t* this, const char* str)
{
    return this->addn(this, str, strlen(str));
}

int circle_buffer_find_char(circle_buffer_t* this, const char findme, int start) {
    if (circle_buffer_empty(this) ) {
        return -1;
    }
    if (this->used(this) < start) {
        return -1;
    }
    int pos = circle_buffer_ptr_inc(this, this->head, start);
    while(pos != this->tail) {
        if (this->buffer[pos] == findme) {            
            return (pos - this->head + this->size) % this->size;
        }
        pos = circle_buffer_ptr_inc(this, pos, 1);
    }
    return -1;
}

int circle_buffer_find(circle_buffer_t* this, const char* findme) {        
    if (circle_buffer_empty(this) ) {
        return -1;
    }
    
    if (strlen(findme) > this->used(this) ) {
        return -1;
    }
    int pos = circle_buffer_find_char(this, findme[0], 0);
    if (pos == -1) {
         return -1;
    }
    int len = strlen(findme);
    if (len == 1) {
        return pos;
    }
    while(pos != -1) {
        int offset = circle_buffer_ptr_inc(this, this->head, pos);
        _Bool found = true; 
        for(int i = 1; i < len; ++i) {            
            offset = circle_buffer_ptr_inc(this, offset, 1);
            if (offset == this->tail) {
                return -1;
            }
            if (this->buffer[offset] != findme[i]) {
                found = false;
                break;
            }
        }
        if (found) {
            return pos;
        }
        pos = circle_buffer_find_char(this, findme[0], pos + 1);    
    }
    return -1;
}

ssize_t circle_buffer_drop(circle_buffer_t* this, size_t len)
{
    if (len <=0) {
        return 0;
    }

    if (len > this->used(this)) {
        return 0;
    }
    this->head = circle_buffer_ptr_inc(this, this->head, len);
    return len;
}

void circle_buffer_pop(circle_buffer_t* this, char* data, ssize_t len)
{
    memcpy(data, this->buffer + this->head, len);
    this->head = circle_buffer_ptr_inc(this, this->head, len);
}

ssize_t circle_buffer_get (circle_buffer_t* this, char* dest, int len)
{
    if (len <= 0) {
        return 0;
    }
    assert(dest != (char*)this); 
    bzero(dest, len);
    ssize_t used = this->used(this);
    if (len > used) {
        len = used;
    }

    /* 使用空间非连续 */
    ssize_t n = len;
    char*   p = dest;

    if (this->head > this->tail) {
        if (n <= this->size - this->head) {
            circle_buffer_pop(this, dest, n);
            return len;
        }
        ssize_t cpy_len = this->size - this->head;
        circle_buffer_pop(this, dest, cpy_len);
        p = p + cpy_len;
        n = n - cpy_len;
    }
    /* 使用空间连续 */
    circle_buffer_pop(this, p, n); 

    return len;
}

struct circle_buffer *new_circle_buffer(const int len) 
{
    circle_buffer_t* buff = malloc(sizeof(circle_buffer_t));
    bzero(buff, sizeof(circle_buffer_t));
    buff->size   = len + 1; //  +1 for 为了循环队满判断

    char* buffer = malloc(buff->size);
    buff->buffer = buffer;

    buff->init  = circle_buffer_init;
    buff->reset = circle_buffer_reset;
    buff->clean = circle_buffer_clean;
    buff->add   = circle_buffer_add;
    buff->addn  = circle_buffer_addn;
    buff->get   = circle_buffer_get;
    buff->used  = circle_buffer_used;
    buff->free  = circle_buffer_free;
    buff->drop  = circle_buffer_drop;
    buff->find  = circle_buffer_find;

    buff->add_from_fd  = circle_buffer_add_from_fd;
    buff->addn_from_fd = circle_buffer_addn_from_fd;

    buff->init(buff);
    
    return buff;
}

