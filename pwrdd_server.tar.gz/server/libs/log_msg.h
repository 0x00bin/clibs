#pragma once

#define LOG_MSG_NAME_SIZE 16
#define LOG_MSG_DATA_SIZE 1024
typedef struct log_msg_st{
    char name[LOG_MSG_NAME_SIZE];
    char data[LOG_MSG_DATA_SIZE];
} log_msg_t;

#define LOG_UDP_SOCK "log.sock"
