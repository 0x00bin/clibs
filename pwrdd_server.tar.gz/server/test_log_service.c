#include "log_service.h"
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void* run_log_service(void *para) {
    log_service_run("logs", "debug", "file");
    return NULL;
}

void* test_thread(void *arg) {

    for(int i = 0; i < 10000; i++) {
   //     printf("%d\n", i);
        sleep(1);
    }
    return NULL;
}

int main() {

    pthread_t tid;
    int err = pthread_create(&tid, NULL, run_log_service, NULL);
    if (err != 0) {
        printf("create thread error.\n");
        return 1;
    }
      
    pthread_t tid1;
    
    err = pthread_create(&tid1, NULL, test_thread, NULL);
    if (err != 0) {
        printf("create thread error.\n");
        return 1;
    }

    if ( pthread_join(tid, NULL) )  
    { 
        printf("Error Joining thread");  
        return 1;  
    }  

    printf("main over!\n");
    return 0;
}
