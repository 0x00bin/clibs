#include "pwrdd_events.h"

char *pwrdd_events_str[5] = {
	"",
	"PWRDD_LISTERNER",
	"PWRDD_CONNECTOR",
	"PWRDD_SIGNAL"
};

char* pwrdd_events_types_2_string (int t)
{
	return pwrdd_events_str[t];
}
