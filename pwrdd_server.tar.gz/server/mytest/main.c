#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>

#include "plugin.h"
#include "plugins.h"
#include "codec.h"

#include "reactor.h"
#include "server.h"
#include "connection.h"
#include "circle_buffer.h"
#include "protocols.h"

plugins_t* plugins;

void onmessage(connection_t* connection, circle_buffer_t* buffer, void* ptr) {
    codec_t codec;
    codec_t* codec_ptr = &codec; 
    if ( codec_init(codec_ptr, buffer) != 0) {
        return;
    }
    
    int protocol = codec_ptr->get_int(codec_ptr, "protocol");

    char modname[16];
    codec_ptr->get_string(codec_ptr, "protocol", modname);

    printf("protocol:%d\n", protocol);
    printf("mod:%s\n", modname);
    codec_ptr->destroy(codec_ptr);
     
    if (protocol == CHECK_AUTH) {
        // send fd to mod     
        connection->reactor->remove_handler(connection->reactor, (handler_t*)connection);
        plugin_t* file = plugins->get(plugins, "file");
        if (file->send_fd(file, connection->handle) > 0) {
            connection->close(connection);
        }
    } else {
        // error close socket
    }
    
    //bzero(data, pos+2);
    //sprintf(data, "hello,%d", connection->handle);
    //connection->send(connection, data, strlen(data));
}

void onconnection(connection_t* connection) { 
    printf("onconnection\n");
    //plugin_t* test = plugins->get(plugins, "test");
}

int main()
{
    reactor_t*  reactor  = reactor_create(10);
    server_t*   server   = server_create(reactor, "127.0.0.1", 8889);
    server->start(server);
    // set onmessage onconnection callback
    server->onmessage    = onmessage;
    server->onconnection = onconnection;
    
    //
    plugins = new_plugins();    
    plugins->load(plugins, "file", "mods");
    
    printf("pid:%d\n", getpid()) ;
    while(1) {
        reactor->register_handler(reactor, (handler_t*)server->acceptor, ReadEvent);
        reactor->handle_events(reactor, 100);
    }

    //plugin_t* test = plugins->get(plugins, "test");
    //char buff[1024];
    //int i = 0;
    /*while(1) {
        bzero(buff, 1024);
        sprintf(buff, "hello %d", i++);
        printf("in main. send:%s\n", buff);            
        test->send(test, buff, strlen(buff));
        fflush(stdout);
        sleep(1);
         
    }*/
    return 0;
}
