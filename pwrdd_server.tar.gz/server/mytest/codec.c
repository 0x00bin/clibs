#include <stdio.h>
#include "codec.h"
#include "json/json.h"
#include "json/json_helper.h"
#include "libs/circle_buffer.h"

void codec_get_string(codec_t* this, const char* key, char* value)
{
    json_get_string_from_object(this->root, key, value);
}

int codec_get_int(codec_t* this, const char* key)
{
    return json_get_int_from_object(this->root, key);
}

void codec_destroy(codec_t* this)
{
    json_value_free(this->root);
}

int codec_init(codec_t* this, circle_buffer_t* buffer)
{
    int pos = buffer->find(buffer, "\r\n");
    if (pos == -1) {
        printf("message not recv complated.\n");
        return -1;
    }
    char data[pos+2]; 
    buffer->get(buffer, data, pos + 2);
    data[pos] = '\0';
    printf("data:%s\n", data);
     
    char error[256];
    json_settings settings = {0};    
    this->root = json_parse_ex(&settings, data, strlen(data), error);
    if (this->root == 0) {
        printf("json parse error:%s\n", error);
        return -1;
    }

    this->get_string = codec_get_string;
    this->get_int    = codec_get_int;
    this->destroy    = codec_destroy;
    
    return 0;
}
