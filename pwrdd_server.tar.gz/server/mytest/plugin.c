#include "plugin.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <strings.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <errno.h>

void close_channel(int *fd) {
    close(fd[0]);
    close(fd[1]);
}

int plugin_init_channel(plugin_t* this) 
{
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, this->channel) == -1) {
        return -1;
    }

    if (set_nonblocking(this->channel[0]) == -1) {
        goto error;
    }

    if (set_nonblocking(this->channel[1]) == -1) {
        goto error;
    }

    int on = 1;
    if (ioctl(this->channel[0], FIOASYNC, &on) == -1) {        
        goto error; 
    }

    if (fcntl(this->channel[0], F_SETOWN, getpid()) == -1) {
        goto error;
    }

    if (set_cloexec(this->channel[0]) == -1) {
        goto error;
    }

    if (set_cloexec(this->channel[1]) == -1) {
        goto error;
    }
    return 0;

error:
    close_channel(this->channel);
    return -1;
}


_Bool plugin_load(plugin_t* this, const char* path) {
    // load so
    char fname[32];
    bzero(fname, 32);
    sprintf(fname, "%s/%s_mod.so", path, this->name);
    if (NULL == (this->lib = dlopen(fname, RTLD_NOW | RTLD_GLOBAL))) {
        printf("dlopen failed for: %s\n", fname);
        return false;
    }

    // plugin_init 
    bzero(fname, 32);
    sprintf(fname, "%s_plugin_init", this->name);
    this->init = (int (*) (plugin_t*)) dlsym(this->lib, fname);
    const char* error;
    if ((error = dlerror()) != NULL) {    
        printf("error:%s\n", error);
        return false;
    }
    if (this->init(this) == -1) {
        printf("%s plugin init failed.\n", this->name);
        return false;
    }

    return true;
}

void plugin_start(plugin_t* this) {
    int pid = fork();

    switch (pid) {
        case -1:            
            // 处理进程创建错误
            this->clean(this);
            return;
        case 0:
            // 启动子进程的循环
            close(this->channel[0]);
            this->loop(this);
        default:
            close(this->channel[1]);
            break;
    }
}

int send_fd(int fd, int sendfd)
{
    struct msghdr   msg;
    struct iovec    iov[1];
    char            buf[1];
    union {
        struct cmsghdr  cm;
        char            control[CMSG_SPACE(sizeof(int))];
    }control_un;
    struct cmsghdr *cmptr;

    msg.msg_control    = control_un.control;
    msg.msg_controllen = sizeof(control_un.control);

    cmptr = CMSG_FIRSTHDR(&msg);
    cmptr->cmsg_len   = CMSG_LEN(sizeof(int));
    cmptr->cmsg_level = SOL_SOCKET;
    cmptr->cmsg_type  = SCM_RIGHTS;
    *((int*) CMSG_DATA(cmptr)) = sendfd;

    msg.msg_name    = NULL;
    msg.msg_namelen = 0;

    iov[0].iov_base = buf;
    iov[0].iov_len  = 1;
    msg.msg_iov     = iov;
    msg.msg_iovlen  = 1;
    return sendmsg(fd, &msg, 0);
}

int plugin_send_fd(plugin_t* this, int sendfd) {
    int n = send_fd(this->channel[0], sendfd);
    if (n <= 0 ) {
        printf("send_fd err:%d\n", errno); 
    } 
    return n;
}

int recv_fd(int fd, int *recvfd)
{    
    struct msghdr   msg;
    struct iovec    iov[1];
    char            buf[1];

    union {
        struct cmsghdr cm;
        char control[CMSG_SPACE(sizeof(int))];
    } control_un;
    struct cmsghdr *cmptr;

    msg.msg_control       = control_un.control;
    msg.msg_controllen    = sizeof(control_un.control);

    msg.msg_name    = NULL;
    msg.msg_namelen = 0;

    iov[0].iov_base = buf;
    iov[0].iov_len  = 1;
    msg.msg_iov     = iov;
    msg.msg_iovlen  = 1;
    int n;
    if ((n = recvmsg(fd, &msg, 0)) <= 0) {
        return n;
    }

    // 检查是否收到辅助数据 
    cmptr = CMSG_FIRSTHDR(&msg);
    if ((cmptr != NULL) && (cmptr->cmsg_len == CMSG_LEN(sizeof(int))) ) {
        if (cmptr->cmsg_level != SOL_SOCKET) {
            printf("control level != SOL_SOCKET\n");
            return -1;
        }

        if (cmptr->cmsg_type != SCM_RIGHTS) {
            printf("control type != SCM_RIGHTS\n");
            return -1;
        }
        *recvfd = *((int*)CMSG_DATA(cmptr));
    } else {
        printf("fd was not passed\n");
        *recvfd = -1;
    }

    return n;
}

int plugin_recv_fd(plugin_t* this) 
{
    int recvfd;
    recv_fd(this->channel[1], &recvfd);
    return recvfd;
}

int plugin_send(plugin_t* this, const void* data, int len) 
{            
    return write(this->channel[0], data, len);    
}

int plugin_recv(plugin_t* this, void* data, int len) 
{
    return read(this->channel[0], data, len);
}

void plugin_clean(plugin_t* this) 
{
    close_channel(this->channel);
    free(this);
}

plugin_t* new_plugin(const char* name) {
    plugin_t* this = malloc(sizeof(plugin_t));
    this->pid = -1;
    memcpy(this->name, name, strlen(name));
    if (plugin_init_channel(this) == -1) {
        free(this);
        return NULL;
    }
    this->clean = plugin_clean;
    this->load  = plugin_load;
    this->start = plugin_start;
    this->send  = plugin_send;
    this->recv  = plugin_recv;

    this->send_fd = plugin_send_fd;
    this->recv_fd = plugin_recv_fd;
    return this;
}
