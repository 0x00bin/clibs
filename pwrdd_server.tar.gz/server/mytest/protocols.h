#pragma once

typedef enum {
    CHECK_AUTH = 100,
    MOD_ISREADY,
    
    FILE_SEND  = 1000,
    FILE_SEND_COMPLETED,
} protocol_t;

