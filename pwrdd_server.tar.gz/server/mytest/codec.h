#pragma once

struct _json_value;
struct circle_buffer;

typedef struct codec_{
    struct _json_value* root;
    void (*get_string) (struct codec_* this, const char* key, char* value);
    int  (*get_int)    (struct codec_* this, const char* key);
    void (*destroy)    (struct codec_* this);
} codec_t;

int codec_init(codec_t* codec, struct circle_buffer* buffer);

