#pragma once

#ifndef CORE_MODS_MAX
#define CORE_MODS_MAX 100
#endif
struct plugin;
struct configure_server;

typedef struct plugins {
    int nums;
    struct plugin* plugins[CORE_MODS_MAX];
    struct plugin* (*get)     (struct plugins* this, const char* name);
    void           (*add)     (struct plugins* this, struct plugin* p);
    void           (*loads)   (struct plugins* this, struct configure_server* conf);
    void           (*load)    (struct plugins* this, const char* pname, const char* dir);
} plugins_t;

plugins_t* new_plugins();
