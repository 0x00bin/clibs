#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include "reactor/reactor.h"
#include "reactor/client.h"
#include "reactor/address.h"
#include "reactor/connection.h"
#include "libs/circle_buffer.h"
#include "protocols.h"
#include "codec.h"

typedef struct fnode_t {
    int   offset;   // file offset
    int   length;   // file length
    char  name[32]; // fname
    FILE* handle;   // file handle
}fnode_t;

fnode_t fnode;
_Bool is_sending;
//char fname[32] = {0};
void onconnection(connection_t* connection) {
    //printf("onconecton\n");
    char msg[256] = {0};
    sprintf(msg, "{\"protocol\":100,\"mod\":\"file\"}\r\n");
    connection->send(connection, msg, strlen(msg));
}

_Bool send_file(connection_t* connection) 
{
    if (fnode.handle == NULL) {
        fnode.handle = fopen(fnode.name, "r");
        if (fnode.handle == NULL) {
            printf("open [%s] error.\n", fnode.name);
            return true;
        }
    }

    if (fnode.length == 0) {
        // obtain file size:
        fseek (fnode.handle, 0, SEEK_END);
        fnode.length = ftell (fnode.handle);
        rewind (fnode.handle);        
    }

    fseek(fnode.handle, fnode.offset, SEEK_SET);
    char buff[4096];
    int n = fread(buff, 1, 4096, fnode.handle);
    if (n < 4096 && !feof(fnode.handle)) {
        printf("fread error %s.\n", fnode.name);
        return true;
    }

    if (fnode.offset == 0) {
        // send_head
    }

    //send_body(fnode, buffer, n);
    fnode.offset += n;
    if (fnode.offset >= fnode.length) {
        // send is end
        fclose(fnode.handle);
        printf("send is end.\n");
        return true;
    }
    return false;
}

void onmessage(connection_t* connection, struct circle_buffer* buffer, void* ptr) {
    printf("onmessage\n");
    size_t used = buffer->used(buffer);
    char buff[256] = {0};
    buffer->get(buffer, buff, used);
    printf("msg:%s\n", buff);
    //char msg[256] = {0};
    //sprintf(msg, "{\"protocol\":100,\"mod\":\"file\"}\r\n");
    //connection->send(connection, msg, strlen(msg)) 
    // TODO check MOD_ISREADY
    codec_t codec;
    codec_t* codec_ptr = &codec;
    if (codec_init(codec_ptr, buffer) != 0) {
        return;
    }
    int protocol = codec_ptr->get_int(codec_ptr, "protocol");
    if (protocol == MOD_ISREADY) {
        send_file(connection);
    }

    if (protocol == FILE_SEND_COMPLETED) {
       is_sending = false; 
    }
    codec_ptr->destroy(codec_ptr);
    // send file    
}

int main(int argc, char ** argv)
{
    if (argc < 3)
    {
        fprintf(stderr, "usage: %s ip port\n", argv[0]);
        return 0;
    }

    reactor_t*  reactor  = reactor_create(10); 
    client_t*   client   = new_client(reactor);
    address_t  address;
    if ( !address_init(&address, atoi(argv[2]), argv[1]) ) {
        printf("address init error:%s", strerror(errno));
    }
    client->onmessage    = onmessage;
    client->onconnection = onconnection;
    if (!client->connect(client, &address) )
    {
        fprintf(stderr, "connect remote server failed\n");
        return 0;
    }
    char fname[32];
    for(;;) {
        scanf("%s", fname);
        if ( access(fname, F_OK | R_OK) == 0) {
            fnode.offset = 0;
            fnode.handle = NULL;
            memcpy(fnode.name, fname, strlen(fname));        
            is_sending = true;
        } else {
            is_sending = false;
        }
        while (is_sending) {
            reactor->handle_events(reactor, 100); 
        }
    }
    return 0;
}
