#pragma once 

#include <sys/types.h>
#include <stdbool.h>

typedef struct plugin {
    pid_t pid;
    char  name[16];
    int   channel[2];
    _Bool is_parent;
    int   slot;  // 
    void* lib;

    int   (*init)    (struct plugin* this); // virtual
    void  (*loop)    (struct plugin* this); // virtual
    _Bool (*load)    (struct plugin* this, const char* path);
    void  (*clean)   (struct plugin* this);
    void  (*start)   (struct plugin* this);
    int   (*send)    (struct plugin* this, const void* data, int len);
    int   (*recv)    (struct plugin* this, void* data, int len);
    int   (*send_fd) (struct plugin* this, int fd); 
    int   (*recv_fd) (struct plugin* this);
} plugin_t;

plugin_t* new_plugin(const char* name);

#define set_nonblocking(s)  fcntl(s, F_SETFL, fcntl(s, F_GETFL) | O_NONBLOCK)
#define set_cloexec(s)      fcntl(s, F_SETFD, FD_CLOEXEC)
