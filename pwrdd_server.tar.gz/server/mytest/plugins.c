#include <stdlib.h>
#include <string.h>

#include "plugin.h"
#include "plugins.h"
#include "configure.h"

plugin_t* plugins_get(plugins_t* this, const char* name) 
{ 
    for(int i = 0; i < CORE_MODS_MAX; ++i) {
        if (this->plugins[i] != NULL) {
            if (strcmp(this->plugins[i]->name, name) == 0) {
                return this->plugins[i];
            }
        }
    }
    return NULL;
}

void plugins_add(plugins_t* this, plugin_t* p) 
{    
    int i = 0;
    for(; i < CORE_MODS_MAX; ++i) {
        if (this->plugins[i] == NULL) {
            break;
        }
    }
    this->nums++;
    this->plugins[i] = p;
    p->slot = i;
}

void plugins_load(plugins_t* this, const char* pname, const char* dir) {    
    plugin_t* p = new_plugin(pname);
    if (p != NULL) {
        if (p->load(p, dir) ) {
            p->start(p);
            this->add(this, p);
        } else {
            printf("plugin:%s load error.\n", pname);
            p->clean(p);
        }
    }
}   

void plugins_loads(plugins_t* this, configure_server_t* conf)
{
    for(int i = 0; i < conf->mods_num; ++i) {
        this->load(this, conf->core_mods[i], conf->mods_dir);
    }
}

plugins_t* new_plugins() {
    plugins_t* this = malloc(sizeof(plugins_t));
    for(int i = 0; i < CORE_MODS_MAX; ++i) {
        this->plugins[i] = NULL;
    }
    this->nums  = 0;
    this->get   = plugins_get;
    this->add   = plugins_add;
    this->load  = plugins_load;
    this->loads = plugins_loads;
    return this;    
}

