#!/bin/sh

gcc file.c ../plugin.c -fPIC -I.. -shared -o file_mod.so
