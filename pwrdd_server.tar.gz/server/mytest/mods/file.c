#include <stdio.h>
#include <strings.h>
#include <plugin.h>
#include <reactor.h>
#include <handler.h>
#include <connection.h>
#include <circle_buffer.h>
#include <acceptor.h>
#include <protocols.h>
#include <hash.h>
#include <codec.h>

plugin_t*       g_plugin;
//hash_table_t*   g_fnodes;
hash_table_t* get_fnodes() {
    //return g_fnodes;
    static hash_table_t* instance = NULL;
    if (instance == NULL) {
        instance = hash_table_create(100);
    }

    return instance;
}

typedef struct fnode_{
    FILE* handle;
    int   id;      //
    int   size;    //
    int   recv_size; // recv len
}fnode_t;

fnode_t* new_fnode(const char* fname, int id, int size) 
{
    fnode_t* this = malloc(sizeof(fnode_t));
    this->handle = fopen(fname, "w");
    if (this->handle == NULL) {
        printf("%s open error.\n", fname);
        return NULL;
    }
    this->id   = id;
    this->size = size;

    return this;
}

fnode_t* create_fnode_by_codec(codec_t* codec_ptr) 
{    
    int id   = codec_ptr->get_int(codec_ptr, "id");
    int size = codec_ptr->get_int(codec_ptr, "size"); 
    hash_table_t* fnodes = get_fnodes();
    char name[16] = {0};
    codec_ptr->get_string(codec_ptr, "name", name);
    char path[64] = {0}; 
    codec_ptr->get_string(codec_ptr, "path", path);
    char fname[128] = {0};
    sprintf(fname, "%s/%s", path, name);

    return  new_fnode(fname, id, size);
}

void file_write(circle_buffer_t* buffer, fnode_t* fnode, connection_t* connection)
{
    int  len = buffer->used(buffer);
    char buff[len];
  
    if (len > fnode->size - fnode->recv_size) {
        len = fnode->size - fnode->recv_size;
    }
    int n = buffer->get(buffer, buff, len);
    fnode->recv_size += n;
    n = fwrite(buff, sizeof(char), sizeof(buff), fnode->handle);
    if (n <= 0) {
        printf("fwrite error.\n");    
    }
    if (fnode->size == fnode->recv_size) {
        printf("recv file complated.\n");
        
        char msg[256] = {0};
        sprintf(msg, "{\"protocol\":%d,\"id\":%d,\"code\":0}\r\n", FILE_SEND, fnode->id);
        connection->send(connection, msg, strlen(msg));
    } 
}

void onmessage(connection_t* connection, circle_buffer_t* buffer, void* ptr) {   
    printf("recv message\n");        
    hash_table_t* fnodes = get_fnodes();
    fnode_t* fnode = (fnode_t*)fnodes->find(fnodes, connection->handle);
    if (fnode != NULL) {
        file_write(buffer, fnode, connection);
        return;
    }
    codec_t codec;
    codec_t* codec_ptr = &codec;
    if (codec_init(codec_ptr, buffer) != 0) {
        return;
    }
    int protocol = codec_ptr->get_int(codec_ptr, "protocol");
    if (protocol == FILE_SEND) {
        // todo hash  fd -> fnode
        fnode_t* fnode = create_fnode_by_codec(codec_ptr);
        if (fnode == NULL) {
            return;
        }

        hash_table_t* fnodes = get_fnodes();
        fnodes->add(fnodes, connection->handle, fnode);
        file_write(buffer, fnode, connection);
        return;
    }

}

// set acceptor.onread = unix_domain_onread;
void unix_domain_onread(handler_t* handler)
{
    int fd = g_plugin->recv_fd(g_plugin);
    if (fd <= 0) {
        return;
    }
    printf("recv fd:%d\n", fd);
    connection_t* connection = connection_create(fd, handler->reactor);    
    connection->onmessage = onmessage;
    // send check_auth
    char msg[256] = {0};
    sprintf(msg, "{\"protocol\":%d,\"mod\":\"file\"}\r\n", MOD_ISREADY);    
    connection->send(connection, msg, strlen(msg));

    handler->reactor->register_handler(handler->reactor, (handler_t*)(connection), WriteEvent); 
}

void file_plugin_loop(plugin_t* p) 
{
    //char buff[1024];
    printf("pid:%d, in %s\n", getpid(), __func__);
    g_plugin = p;
    //g_fnodes = hash_table_create(100);

    reactor_t*  reactor  = reactor_create(10); 
    acceptor_t* acceptor = acceptor_create(NULL, p->channel[1], reactor);

    acceptor->onread  = unix_domain_onread;

    for(;;) {
        reactor->register_handler(reactor, (handler_t*)acceptor, ReadEvent);
        reactor->handle_events(reactor, 100);
    }
}

int file_plugin_init(plugin_t* p) {
    p->loop = file_plugin_loop;
    printf("in %s\n", __func__);
    return 0;
}
