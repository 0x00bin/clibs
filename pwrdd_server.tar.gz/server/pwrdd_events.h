#pragma once
#include "libs/kernel_list.h"

typedef enum pwrdd_events_types {
	PWRDD_LISTERNER=1,
	PWRDD_CONNECTOR,
	PWRDD_SIGNAL
} pwrdd_events_types_t;

/**
 * @brief 注册到reactor中用于回调的信息
 */
typedef struct pwrdd_events {
	struct list_head list;		/*链表结构*/

	pwrdd_events_types_t type;	/*用于表明ptr的内容*/

	char ip[16]; 			/*ip 连接进来的ip*/

	int port; 			/*连接进来的端口*/

	int sock; 			/*分配的fd*/

	void *ptr;

	int (*init)  (struct pwrdd_events *this);

	void (*clean) (struct pwrdd_events  *this);

}pwrdd_events_t;


/**
 * @brief 把pwrdd_events_type转换成一个字符串
 */
inline char* pwrdd_events_types_2_string (int t);


/**
 * @brief 专门用于打印pwrdd_events的内容
 */
#define PWRDD_EVENT_PRT(LOG_LEVEL, PREFIX, OBJ) LOG_LEVEL( \
		"ip=%s:port=%d:sock=%d:type=%s:ptr=%p:msg=%s", \
		OBJ->ip, OBJ->port, OBJ->sock, pwrdd_events_types_2_string(OBJ->type), OBJ->ptr, PREFIX)
